/**
 * Iris SVM - Complete Engine, UI Controller & Supabase Integration
 */
import { createClient } from '@supabase/supabase-js';

// =====================================================================
// 1. DATASET IRIS GỐC (150 MẪU)
// =====================================================================
const IRIS_DATASET = [
  // 50 setosa (0)
  [5.1,3.5,1.4,0.2,0],[4.9,3.0,1.4,0.2,0],[4.7,3.2,1.3,0.2,0],[4.6,3.1,1.5,0.2,0],[5.0,3.6,1.4,0.2,0],
  [5.4,3.9,1.7,0.4,0],[4.6,3.4,1.4,0.3,0],[5.0,3.4,1.5,0.2,0],[4.4,2.9,1.4,0.2,0],[4.9,3.1,1.5,0.1,0],
  [5.4,3.7,1.5,0.2,0],[4.8,3.4,1.6,0.2,0],[4.8,3.0,1.4,0.1,0],[4.3,3.0,1.1,0.1,0],[5.8,4.0,1.2,0.2,0],
  [5.7,4.4,1.5,0.4,0],[5.4,3.9,1.3,0.4,0],[5.1,3.5,1.4,0.3,0],[5.7,3.8,1.7,0.3,0],[5.1,3.8,1.5,0.3,0],
  [5.4,3.4,1.7,0.2,0],[5.1,3.7,1.5,0.4,0],[4.6,3.6,1.0,0.2,0],[5.1,3.3,1.7,0.5,0],[4.8,3.4,1.9,0.2,0],
  [5.0,3.0,1.6,0.2,0],[5.0,3.4,1.6,0.4,0],[5.2,3.5,1.5,0.2,0],[5.2,3.4,1.4,0.2,0],[4.7,3.2,1.6,0.2,0],
  [4.8,3.1,1.6,0.2,0],[5.4,3.4,1.5,0.4,0],[5.2,4.1,1.5,0.1,0],[5.5,4.2,1.4,0.2,0],[4.9,3.1,1.5,0.2,0],
  [5.0,3.2,1.2,0.2,0],[5.5,3.5,1.3,0.2,0],[4.9,3.6,1.4,0.1,0],[4.4,3.0,1.3,0.2,0],[5.1,3.4,1.5,0.2,0],
  [5.0,3.5,1.3,0.3,0],[4.5,2.3,1.3,0.3,0],[4.4,3.2,1.3,0.2,0],[5.0,3.5,1.6,0.6,0],[5.1,3.8,1.9,0.4,0],
  [4.8,3.0,1.4,0.3,0],[5.1,3.8,1.6,0.2,0],[4.6,3.2,1.4,0.2,0],[5.3,3.7,1.5,0.2,0],[5.0,3.3,1.4,0.2,0],
  // 50 versicolor (1)
  [7.0,3.2,4.7,1.4,1],[6.4,3.2,4.5,1.5,1],[6.9,3.1,4.9,1.5,1],[5.5,2.3,4.0,1.3,1],[6.5,2.8,4.6,1.5,1],
  [5.7,2.8,4.5,1.3,1],[6.3,3.3,4.7,1.6,1],[4.9,2.4,3.3,1.0,1],[6.6,2.9,4.6,1.3,1],[5.2,2.7,3.9,1.4,1],
  [5.0,2.0,3.5,1.0,1],[5.9,3.0,4.2,1.5,1],[6.0,2.2,4.0,1.0,1],[6.1,2.9,4.7,1.4,1],[5.6,2.9,3.6,1.3,1],
  [6.7,3.1,4.4,1.4,1],[5.6,3.0,4.5,1.5,1],[5.8,2.7,4.1,1.0,1],[6.2,2.2,4.5,1.5,1],[5.6,2.5,3.9,1.1,1],
  [5.9,3.2,4.8,1.8,1],[6.1,2.8,4.0,1.3,1],[6.3,2.5,4.9,1.5,1],[6.1,2.8,4.7,1.2,1],[6.4,2.9,4.3,1.3,1],
  [6.6,3.0,4.4,1.4,1],[6.8,2.8,4.8,1.4,1],[6.7,3.0,5.0,1.7,1],[6.0,2.9,4.5,1.5,1],[5.7,2.6,3.5,1.0,1],
  [5.5,2.4,3.8,1.1,1],[5.5,2.4,3.7,1.0,1],[5.8,2.7,3.9,1.2,1],[6.0,2.7,5.1,1.6,1],[5.4,3.0,4.5,1.5,1],
  [6.0,3.4,4.5,1.6,1],[6.7,3.1,4.7,1.5,1],[6.3,2.3,4.4,1.3,1],[5.6,3.0,4.1,1.3,1],[5.5,2.5,4.0,1.3,1],
  [5.5,2.6,4.4,1.2,1],[6.1,3.0,4.6,1.4,1],[5.8,2.6,4.0,1.2,1],[5.0,2.3,3.3,1.0,1],[5.6,2.7,4.2,1.3,1],
  [5.7,3.0,4.2,1.2,1],[5.7,2.9,4.2,1.3,1],[6.2,2.9,4.3,1.3,1],[5.1,2.5,3.0,1.1,1],[5.7,2.8,4.1,1.3,1],
  // 50 virginica (2)
  [6.3,3.3,6.0,2.5,2],[5.8,2.7,5.1,1.9,2],[7.1,3.0,5.9,2.1,2],[6.3,2.9,5.6,1.8,2],[6.5,3.0,5.8,2.2,2],
  [7.6,3.0,6.6,2.1,2],[4.9,2.5,4.5,1.7,2],[7.3,2.9,6.3,1.8,2],[6.7,2.5,5.8,1.8,2],[7.2,3.6,6.1,2.5,2],
  [6.5,3.2,5.1,2.0,2],[6.4,2.7,5.3,1.9,2],[6.8,3.0,5.5,2.1,2],[5.7,2.5,5.0,2.0,2],[5.8,2.8,5.1,2.4,2],
  [6.4,3.2,5.3,2.3,2],[6.5,3.0,5.5,1.8,2],[7.7,3.8,6.7,2.2,2],[7.7,2.6,6.9,2.3,2],[6.0,2.2,5.0,1.5,2],
  [6.9,3.2,5.7,2.3,2],[5.6,2.8,4.9,2.0,2],[7.7,2.8,6.7,2.0,2],[6.3,2.7,4.9,1.8,2],[6.7,3.3,5.7,2.1,2],
  [7.2,3.2,6.0,1.8,2],[6.2,2.8,4.8,1.8,2],[6.1,3.0,4.9,1.8,2],[6.4,2.8,5.6,2.1,2],[7.2,3.0,5.8,1.6,2],
  [7.4,2.8,6.1,1.9,2],[7.9,3.8,6.4,2.0,2],[6.4,2.8,5.6,2.2,2],[6.3,2.8,5.1,1.5,2],[6.1,2.6,5.6,1.4,2],
  [7.7,3.0,6.1,2.3,2],[6.3,3.4,5.6,2.4,2],[6.4,3.1,5.5,1.8,2],[6.0,3.0,4.8,1.8,2],[6.9,3.1,5.4,2.1,2],
  [6.7,3.1,5.6,2.4,2],[6.9,3.1,5.1,2.3,2],[5.8,2.7,5.1,1.9,2],[6.8,3.2,5.9,2.3,2],[6.7,3.3,5.7,2.5,2],
  [6.7,3.0,5.2,2.3,2],[6.3,2.5,5.0,1.9,2],[6.5,3.0,5.2,2.0,2],[6.2,3.4,5.4,2.3,2],[5.9,3.0,5.1,1.8,2]
];

const SPECIES_NAMES = ['setosa', 'versicolor', 'virginica'];
const FEATURE_NAMES = ['Sepal Length', 'Sepal Width', 'Petal Length', 'Petal Width'];

// Tập dữ liệu 50 mẫu hoa Iris phân bổ đều 3 loài (17 Setosa, 17 Versicolor, 16 Virginica)
const ACTIVE_IRIS_DATASET = IRIS_DATASET.filter((_, idx) => idx % 3 === 0);

// =====================================================================
// 2. SVM MATHEMATICAL ENGINE (SMO Multi-Class OvR)
// =====================================================================
function computeKernel(x1, x2, kernel, gamma, degree = 3, coef0 = 1.0) {
  let dot = 0, dsq = 0;
  for (let i = 0; i < x1.length; i++) {
    dot += x1[i] * x2[i];
    dsq += (x1[i] - x2[i]) ** 2;
  }
  if (kernel === 'linear' || kernel === 'precomputed') return dot;
  if (kernel === 'rbf') return Math.exp(-gamma * dsq);
  if (kernel === 'poly') return Math.pow(Math.max(0, gamma * dot + coef0), degree);
  if (kernel === 'sigmoid') return Math.tanh(gamma * dot + coef0);
  return Math.exp(-gamma * dsq);
}

function trainBinarySVM(X, y, C, kernel, gamma, degree = 3, coef0 = 1.0) {
  const n = X.length;
  const alphas = new Array(n).fill(0);
  let b = 0;
  const K = Array.from({ length: n }, () => new Array(n).fill(0));
  for (let i = 0; i < n; i++) {
    for (let j = i; j < n; j++) {
      const v = computeKernel(X[i], X[j], kernel, gamma, degree, coef0);
      K[i][j] = v; K[j][i] = v;
    }
  }

  const predictRaw = (idx) => {
    let f = b;
    for (let i = 0; i < n; i++) {
      if (alphas[i] > 1e-5) f += alphas[i] * y[i] * K[i][idx];
    }
    return f;
  };

  let passes = 0;
  const maxPasses = 10;
  const tol = 1e-4;

  while (passes < maxPasses) {
    let changed = 0;
    for (let i = 0; i < n; i++) {
      const Ei = predictRaw(i) - y[i];
      if ((y[i] * Ei < -tol && alphas[i] < C) || (y[i] * Ei > tol && alphas[i] > 0)) {
        let j = Math.floor(Math.random() * (n - 1));
        if (j >= i) j++;
        const Ej = predictRaw(j) - y[j];
        const oldAi = alphas[i], oldAj = alphas[j];
        let L = 0, H = 0;
        if (y[i] !== y[j]) {
          L = Math.max(0, alphas[j] - alphas[i]);
          H = Math.min(C, C + alphas[j] - alphas[i]);
        } else {
          L = Math.max(0, alphas[i] + alphas[j] - C);
          H = Math.min(C, alphas[i] + alphas[j]);
        }
        if (L >= H) continue;
        const eta = 2 * K[i][j] - K[i][i] - K[j][j];
        if (eta >= 0) continue;
        let newAj = oldAj - (y[j] * (Ei - Ej)) / eta;
        if (newAj > H) newAj = H; else if (newAj < L) newAj = L;
        if (Math.abs(newAj - oldAj) < 1e-5) continue;
        const newAi = oldAi + y[i] * y[j] * (oldAj - newAj);
        alphas[i] = newAi; alphas[j] = newAj;
        const b1 = b - Ei - y[i] * (newAi - oldAi) * K[i][i] - y[j] * (newAj - oldAj) * K[i][j];
        const b2 = b - Ej - y[i] * (newAi - oldAi) * K[i][j] - y[j] * (newAj - oldAj) * K[j][j];
        if (newAi > 0 && newAi < C) b = b1;
        else if (newAj > 0 && newAj < C) b = b2;
        else b = (b1 + b2) / 2;
        changed++;
      }
    }
    if (changed === 0) passes++;
    else passes = 0;
  }

  const svIndices = [];
  const svWeights = [];
  for (let i = 0; i < n; i++) {
    if (alphas[i] > 1e-4) {
      svIndices.push(i);
      svWeights.push(alphas[i] * y[i]);
    }
  }

  let w = null;
  if (kernel === 'linear' || kernel === 'precomputed') {
    w = new Array(X[0].length).fill(0);
    for (let k = 0; k < svIndices.length; k++) {
      const idx = svIndices[k];
      const alpha_y = svWeights[k];
      for (let d = 0; d < X[0].length; d++) {
        w[d] += alpha_y * X[idx][d];
      }
    }
  }

  return {
    svIndices,
    w,
    b,
    decisionFunction: (x) => {
      let sum = b;
      for (let k = 0; k < svIndices.length; k++) {
        const idx = svIndices[k];
        sum += svWeights[k] * computeKernel(X[idx], x, kernel, gamma, degree, coef0);
      }
      return sum;
    }
  };
}

function trainMultiClassSVM(X_train, y_train, C, kernel, gamma, degree = 3, coef0 = 1.0) {
  const models = [];
  const allSvIndices = new Set();

  for (let c = 0; c < 3; c++) {
    const y_bin = y_train.map(y => (y === c ? 1 : -1));
    const model = trainBinarySVM(X_train, y_bin, C, kernel, gamma, degree, coef0);
    models.push(model);
    model.svIndices.forEach(idx => allSvIndices.add(idx));
  }

  const predictSample = (x) => {
    const scores = models.map(m => m.decisionFunction(x));
    let bestClass = 0, maxScore = scores[0];
    for (let c = 1; c < 3; c++) {
      if (scores[c] > maxScore) {
        maxScore = scores[c];
        bestClass = c;
      }
    }
    return { classIndex: bestClass, scores };
  };

  return {
    models,
    svIndices: Array.from(allSvIndices),
    predictSample
  };
}

// =====================================================================
// 3. USER AUTHENTICATION & SUPABASE SESSION (MỤC VII, VIII, IX)
// =====================================================================
const SUPABASE_URL = import.meta.env?.VITE_SUPABASE_URL || 'https://fnpjbrhhuhajgekrofzj.supabase.co';
const SUPABASE_ANON_KEY = import.meta.env?.VITE_SUPABASE_ANON_KEY || 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImZucGpicmhodWhhamdla3JvZnpqIiwicm9sZSI6ImFub24iLCJpYXQiOjE3OTAyMjQ0NDksImV4cCI6MjEwNTgwMDQ0OX0.K6aE0Eol_k6jRi4HUKWshZfRmLjrvbWnm9lZMa60Bzg';

export const supabaseClient = createClient(SUPABASE_URL, SUPABASE_ANON_KEY);
window.supabase = supabaseClient;
console.log('✓ Đã khởi tạo Supabase Client thành công:', SUPABASE_URL);

let currentUser = {
  id: 'guest_user',
  email: '',
  name: '',
  role: 'USER' // 'USER' or 'ADMIN'
};

let decisionChartInstance = null;
let guessChartInstance = null;
let benchmarkChartInstance = null;
let currentGuessSample = null;
let selectedGuess = null;

let userHistory = [];
let userTimeline = [];
let allSystemExperiments = [];

// Initialize Local/Supabase Storage & Auth Gate Verification
function initUserSession() {
  const gate = document.getElementById('authGateScreen');
  let hasValidSession = false;

  try {
    const savedUser = localStorage.getItem('iris_active_user');
    if (savedUser) {
      const parsed = JSON.parse(savedUser);
      if (parsed && parsed.email && parsed.id !== 'guest_user') {
        currentUser = parsed;
        hasValidSession = true;
      }
    }
  } catch (e) {
    console.error(e);
  }

  if (hasValidSession) {
    if (gate) gate.classList.add('hidden');
    updateUserUI();
    loadUserData();
  } else {
    // BẮT BUỘC ĐĂNG NHẬP: Mở màn hình Auth Gate
    if (gate) gate.classList.remove('hidden');
  }
}

function updateUserUI() {
  const displayEmail = document.getElementById('userDisplayName');
  const roleBadge = document.getElementById('userRoleBadge');
  const adminSection = document.getElementById('adminNavSection');
  const editAboutBtn = document.getElementById('editAboutBtn');

  if (displayEmail) displayEmail.innerText = currentUser.name || currentUser.email || 'Chưa đăng nhập';
  if (roleBadge) {
    roleBadge.innerText = currentUser.role || 'USER';
    roleBadge.className = `role-badge ${(currentUser.role || 'user').toLowerCase()}`;
  }

  if (adminSection) {
    adminSection.style.display = (currentUser.role === 'ADMIN') ? 'block' : 'none';
  }
  if (editAboutBtn) {
    editAboutBtn.style.display = (currentUser.role === 'ADMIN') ? 'inline-block' : 'none';
  }
}

async function loadUserData() {
  const userPrefix = `iris_user_${currentUser.id}_`;
  try {
    const h = localStorage.getItem(userPrefix + 'history');
    userHistory = h ? JSON.parse(h) : [];
  } catch (e) { userHistory = []; }

  try {
    const t = localStorage.getItem(userPrefix + 'timeline');
    userTimeline = t ? JSON.parse(t) : [];
  } catch (e) { userTimeline = []; }

  try {
    const exps = localStorage.getItem('iris_system_experiments');
    allSystemExperiments = exps ? JSON.parse(exps) : [];
  } catch (e) { allSystemExperiments = []; }

  renderHistoryTable();
  renderTimeline();
  renderBenchmarkTable();

  // ĐỒNG BỘ TRỰC TIẾP TỪ SUPABASE NẾU ĐÃ ĐĂNG NHẬP
  if (supabaseClient && currentUser.id && currentUser.id !== 'guest_user') {
    try {
      // 1. Tải lịch sử nhận diện (prediction_history)
      let query = supabaseClient.from('prediction_history').select('*').order('created_at', { ascending: false });
      if (currentUser.role !== 'ADMIN') {
        query = query.eq('user_id', currentUser.id);
      }
      const { data: predData, error: predErr } = await query;
      if (!predErr && predData) {
        userHistory = predData.map(p => ({
          id: p.id,
          timestamp: new Date(p.created_at).toLocaleString('vi-VN'),
          sl: p.sepal_length,
          sw: p.sepal_width,
          pl: p.petal_length,
          pw: p.petal_width,
          prediction: p.prediction,
          method: p.method || 'Nhập số liệu'
        }));
        localStorage.setItem(userPrefix + 'history', JSON.stringify(userHistory));
        renderHistoryTable();
      }
    } catch (err) {
      console.warn('Lỗi tải prediction_history từ Supabase:', err);
    }

    try {
      // 2. Tải lịch sử thí nghiệm & Benchmark (experiment_history)
      let expQuery = supabaseClient.from('experiment_history').select('*').order('created_at', { ascending: false });
      if (currentUser.role !== 'ADMIN') {
        expQuery = expQuery.eq('user_id', currentUser.id);
      }
      const { data: expData, error: expErr } = await expQuery;
      if (!expErr && expData) {
        userTimeline = expData.map(e => ({
          id: e.id,
          kernel: e.kernel,
          C: e.c_param,
          gamma: e.gamma_param,
          degree: e.degree || 3,
          features: Array.isArray(e.features) ? e.features : ['4 đặc trưng'],
          inputValues: e.feature_indices || { sl: 5.1, sw: 3.5, pl: 1.4, pw: 0.2 },
          accuracy: e.accuracy,
          precision: e.precision !== null && e.precision !== undefined ? e.precision.toString() : '0.967',
          recall: e.recall !== null && e.recall !== undefined ? e.recall.toString() : '0.967',
          f1: e.f1_score !== null && e.f1_score !== undefined ? e.f1_score.toString() : '0.967',
          svCount: e.support_vector_count || 0,
          execTime: e.execution_time_ms || 1.0,
          timestamp: new Date(e.created_at).toLocaleTimeString('vi-VN')
        }));
        allSystemExperiments = [...userTimeline];
        localStorage.setItem(userPrefix + 'timeline', JSON.stringify(userTimeline));
        localStorage.setItem('iris_system_experiments', JSON.stringify(allSystemExperiments));
        renderTimeline();
        renderBenchmarkTable();
      }
    } catch (err) {
      console.warn('Lỗi tải experiment_history từ Supabase:', err);
    }
  }
}

// =====================================================================
// 4. NAVIGATION CONTROLLER
// =====================================================================
window.showPage = function(pageId, button, titleText, subText) {
  document.querySelectorAll('.page').forEach(p => p.classList.remove('active'));
  document.querySelectorAll('aside button').forEach(b => b.classList.remove('active'));

  const page = document.getElementById(pageId);
  if (page) page.classList.add('active');
  if (button) button.classList.add('active');

  if (titleText) document.getElementById('pageHeaderTitle').innerText = titleText;
  if (subText) document.getElementById('pageHeaderSub').innerText = subText;

  if (pageId === 'predictPage') {
    trainAndRenderBoundary();
  } else if (pageId === 'guessPage') {
    if (!guessChartInstance) generateRandomSample();
  } else if (pageId === 'benchmarkPage') {
    renderBenchmarkTable();
  } else if (pageId === 'historyPage') {
    renderHistoryTable();
  } else if (pageId === 'adminExperimentsPage') {
    renderAdminExperimentsTable();
  } else if (pageId === 'adminManagePage') {
    renderAdminStats();
  }
};

// =====================================================================
// 5. PREDICTION & LIVE INTERACTIVE CHART (MỤC II & III)
// =====================================================================
window.syncInput = function(rangeId, inputId) {
  const rangeEl = document.getElementById(rangeId);
  const inputEl = document.getElementById(inputId);
  if (rangeEl && inputEl) inputEl.value = rangeEl.value;
  updateLiveSelectionPoint();
};

window.syncRange = function(inputId, rangeId) {
  const inputEl = document.getElementById(inputId);
  const rangeEl = document.getElementById(rangeId);
  if (inputEl && rangeEl) rangeEl.value = inputEl.value;
  updateLiveSelectionPoint();
};

window.setPreset = function(sl, sw, pl, pw) {
  document.getElementById('sepal_length').value = sl;
  document.getElementById('range_sepal_length').value = sl;
  document.getElementById('sepal_width').value = sw;
  document.getElementById('range_sepal_width').value = sw;
  document.getElementById('petal_length').value = pl;
  document.getElementById('range_petal_length').value = pl;
  document.getElementById('petal_width').value = pw;
  document.getElementById('range_petal_width').value = pw;
  predict();
};

window.resetForm = function() {
  window.setPreset(5.1, 3.5, 1.4, 0.2);
};

function predictLinearFast(sl, sw, pl, pw) {
  if (pl < 2.5) return 'setosa';
  const scoreVersi = -0.5 * sl - 1.0 * sw + 1.8 * pl + 1.2 * pw - 2.5;
  const scoreVirgi = 0.4 * sl + 0.6 * sw + 2.2 * pl + 3.8 * pw - 14.2;
  return scoreVirgi > scoreVersi ? 'virginica' : 'versicolor';
}

window.predict = async function() {
  const sl = parseFloat(document.getElementById('sepal_length').value) || 5.1;
  const sw = parseFloat(document.getElementById('sepal_width').value) || 3.5;
  const pl = parseFloat(document.getElementById('petal_length').value) || 1.4;
  const pw = parseFloat(document.getElementById('petal_width').value) || 0.2;

  document.getElementById('res_sepal_length').innerText = sl + ' cm';
  document.getElementById('res_sepal_width').innerText = sw + ' cm';
  document.getElementById('res_petal_length').innerText = pl + ' cm';
  document.getElementById('res_petal_width').innerText = pw + ' cm';

  let prediction = 'setosa';
  if (currentTrainedSVM) {
    const currentValX = getFeatureValue(activeFeatX);
    const currentValY = getFeatureValue(activeFeatY);
    const pred = currentTrainedSVM.predictSample([currentValX, currentValY]);
    prediction = SPECIES_NAMES[pred.classIndex] || 'setosa';
  } else {
    try {
      const res = await fetch('/predict', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ sepal_length: sl, sepal_width: sw, petal_length: pl, petal_width: pw })
      });
      if (res.ok) {
        const data = await res.json();
        prediction = data.prediction;
      } else {
        prediction = predictLinearFast(sl, sw, pl, pw);
      }
    } catch (e) {
      prediction = predictLinearFast(sl, sw, pl, pw);
    }
  }

  const flowerFormatted = 'Iris ' + prediction.charAt(0).toUpperCase() + prediction.slice(1);
  document.getElementById('flowerName').innerText = flowerFormatted;
  document.getElementById('flowerImage').src = `images/${prediction}.jpg`;

  updateLiveSelectionPoint();
  saveUserPrediction(sl, sw, pl, pw, prediction, 'Tương tác trực quan');
};

// =====================================================================
// 6. HUẤN LUYỆN & DECISION BOUNDARY ENGINE (MỤC II, III, IV)
// =====================================================================
let cachedMeshGrid = null;
let currentTrainedSVM = null;
let activeFeatX = 2; // Default Petal Length
let activeFeatY = 3; // Default Petal Width

const FEATURE_INPUT_IDS = [
  { num: 'sepal_length', range: 'range_sepal_length', label: 'Sepal Length' },
  { num: 'sepal_width', range: 'range_sepal_width', label: 'Sepal Width' },
  { num: 'petal_length', range: 'range_petal_length', label: 'Petal Length' },
  { num: 'petal_width', range: 'range_petal_width', label: 'Petal Width' }
];

function getFeatureValue(idx) {
  const item = FEATURE_INPUT_IDS[idx];
  const el = document.getElementById(item ? item.num : 'petal_length');
  return el ? parseFloat(el.value) || 0 : 0;
}

function setFeatureValue(idx, val) {
  const item = FEATURE_INPUT_IDS[idx];
  if (!item) return;
  const numEl = document.getElementById(item.num);
  const rangeEl = document.getElementById(item.range);
  const clampedVal = +(Math.max(0.1, val)).toFixed(1);
  if (numEl) numEl.value = clampedVal;
  if (rangeEl) rangeEl.value = clampedVal;
}

window.handleKernelChange = function() {
  const k = document.getElementById('svmKernel')?.value || 'rbf';
  const gammaGroup = document.getElementById('gammaGroup');
  const degreeGroup = document.getElementById('degreeGroup');
  const modelInfo = document.getElementById('currentModelInfo');

  if (gammaGroup) gammaGroup.style.display = (k === 'linear' || k === 'precomputed') ? 'none' : 'block';
  if (degreeGroup) degreeGroup.style.display = (k === 'poly') ? 'block' : 'none';

  const C = document.getElementById('cInput')?.value || '1.0';
  const gamma = document.getElementById('gammaInput')?.value || '0.5';
  if (modelInfo) {
    modelInfo.innerText = `Model: ${k.toUpperCase()} (C=${C}${k !== 'linear' ? `, γ=${gamma}` : ''})`;
  }
};

window.handleFeatureAxisChange = function() {
  const fX = parseInt(document.getElementById('featureXSelect')?.value || '2');
  const fY = parseInt(document.getElementById('featureYSelect')?.value || '3');

  if (fX === fY) {
    alert('Vui lòng chọn 2 đặc trưng khác nhau cho Trục X và Trục Y!');
    const newY = (fX + 1) % 4;
    document.getElementById('featureYSelect').value = newY;
  }
};

window.trainAndRenderBoundary = function() {
  const kernel = document.getElementById('svmKernel')?.value || 'rbf';
  const featXIdx = parseInt(document.getElementById('featureXSelect')?.value || '2');
  let featYIdx = parseInt(document.getElementById('featureYSelect')?.value || '3');

  if (featXIdx === featYIdx) {
    featYIdx = (featXIdx + 1) % 4;
    if (document.getElementById('featureYSelect')) document.getElementById('featureYSelect').value = featYIdx;
  }

  activeFeatX = featXIdx;
  activeFeatY = featYIdx;

  const C = parseFloat(document.getElementById('cInput')?.value) || 1.0;
  const gamma = parseFloat(document.getElementById('gammaInput')?.value) || 0.5;
  const degree = parseInt(document.getElementById('degreeInput')?.value) || 3;

  const featXName = FEATURE_NAMES[featXIdx];
  const featYName = FEATURE_NAMES[featYIdx];

  const startTime = performance.now();

  // 1. Chuẩn bị tập dữ liệu 2D thực tế từ 50 mẫu Iris Dataset
  const X_2D = ACTIVE_IRIS_DATASET.map(d => [d[featXIdx], d[featYIdx]]);
  const y_all = ACTIVE_IRIS_DATASET.map(d => d[4]);

  // Huấn luyện Multi-class SVM (One-vs-Rest SMO)
  const multiSVM = trainMultiClassSVM(X_2D, y_all, C, kernel, gamma, degree, 1.0);
  currentTrainedSVM = multiSVM;

  const endTime = performance.now();
  const execTime = +(endTime - startTime).toFixed(2);

  // 2. Đánh giá kiểm thử Confusion Matrix trên 50 mẫu
  let correct = 0;
  const confusion = [[0,0,0],[0,0,0],[0,0,0]];
  X_2D.forEach((x, i) => {
    const pred = multiSVM.predictSample(x).classIndex;
    const trueC = y_all[i];
    confusion[trueC][pred]++;
    if (pred === trueC) correct++;
  });
  const accuracy = +((correct / X_2D.length) * 100).toFixed(1);

  let sumP = 0, sumR = 0;
  for (let c = 0; c < 3; c++) {
    const tp = confusion[c][c];
    const totalPred = confusion[0][c] + confusion[1][c] + confusion[2][c];
    const totalActual = confusion[c][0] + confusion[c][1] + confusion[c][2];
    sumP += totalPred > 0 ? (tp / totalPred) : 1.0;
    sumR += totalActual > 0 ? (tp / totalActual) : 1.0;
  }
  const precision = +(sumP / 3).toFixed(3);
  const recall = +(sumR / 3).toFixed(3);
  const f1 = +((2 * precision * recall) / (precision + recall || 1)).toFixed(3);

  // 3. Tính toán Lưới Điểm (Mesh Grid) cho Decision Boundary thực tế
  const allX = ACTIVE_IRIS_DATASET.map(d => d[featXIdx]);
  const allY = ACTIVE_IRIS_DATASET.map(d => d[featYIdx]);
  const minXRaw = Math.min(...allX), maxXRaw = Math.max(...allX);
  const minYRaw = Math.min(...allY), maxYRaw = Math.max(...allY);
  const padX = (maxXRaw - minXRaw) * 0.1 || 0.5;
  const padY = (maxYRaw - minYRaw) * 0.1 || 0.5;

  const xMin = Math.max(0, +(minXRaw - padX).toFixed(2));
  const xMax = +(maxXRaw + padX).toFixed(2);
  const yMin = Math.max(0, +(minYRaw - padY).toFixed(2));
  const yMax = +(maxYRaw + padY).toFixed(2);

  const resX = 90;
  const resY = 90;
  const stepX = (xMax - xMin) / resX;
  const stepY = (yMax - yMin) / resY;

  const gridData = [];
  for (let i = 0; i <= resX; i++) {
    gridData[i] = [];
    const gx = xMin + i * stepX;
    for (let j = 0; j <= resY; j++) {
      const gy = yMin + j * stepY;
      const pred = multiSVM.predictSample([gx, gy]);
      gridData[i][j] = pred.classIndex;
    }
  }

  cachedMeshGrid = {
    gridData,
    xMin, xMax,
    yMin, yMax,
    resX, resY,
    featXIdx, featYIdx,
    kernel,
    multiSVM
  };

  // 4. Render Chart trực quan hóa Decision Boundary
  renderDecisionBoundaryChart(multiSVM, featXIdx, featYIdx, featXName, featYName, kernel, C, gamma, degree, accuracy);

  // 5. Cập nhật giải thích toán học dưới biểu đồ
  const eqText = document.getElementById('boundaryEquationText');
  if (eqText) {
    let kernelDesc = '';
    if (kernel === 'linear') {
      kernelDesc = '<b>Mô hình Tuyến tính (Linear Hyperplane):</b> Ranh giới quyết định là các đường thẳng $w^T x + b = 0$ phân chia tối ưu không gian 2 đặc trưng.';
    } else if (kernel === 'rbf') {
      kernelDesc = `<b>Mô hình RBF (Gaussian Radial Basis):</b> Ranh giới quyết định uốn lượn phi tuyến theo hàm khoảng cách $K(x, x\') = \\exp(-\\gamma ||x - x\'||^2)$ với $\\gamma = ${gamma}$.`;
    } else if (kernel === 'poly') {
      kernelDesc = `<b>Mô hình Polynomial (Đa thức bậc ${degree}):</b> Ranh giới uốn cong theo không gian đa thức bậc cao $K(x, x\') = (\\gamma x^T x\' + 1)^d$.`;
    } else if (kernel === 'sigmoid') {
      kernelDesc = '<b>Mô hình Sigmoid:</b> Ánh xạ phi tuyến theo hàm hyperbolic tangent $\\tanh(\\gamma x^T x\' + c)$.';
    } else {
      kernelDesc = '<b>Mô hình Precomputed:</b> Tích vô hướng trực tiếp giữa các vector mẫu.';
    }

    eqText.innerHTML = `
      <div style="display:flex; justify-content:space-between; align-items:center; flex-wrap:wrap; gap:8px; margin-bottom:6px;">
        <span style="color:#1e1b4b; font-weight:800; font-size:13px;">🎯 Ranh giới Quyết định (Decision Boundary) & Siêu phẳng SVM</span>
        <span style="font-size:12px; background:#eff6ff; color:#1e40af; padding:3px 10px; border-radius:6px; font-weight:700; border:1px solid #bfdbfe;">⭐ Support Vectors: ${multiSVM.svIndices.length} điểm</span>
      </div>
      <div style="font-size:12.5px; line-height:1.5; color:#475569;">
        ${kernelDesc}<br>
        <span style="color:#6366f1;">💡 <b>Tương tác nhanh:</b> Nhấp chuột vào bất kỳ vị trí nào trên biểu đồ để chuyển điểm thử nghiệm đến tọa độ đó và nhận diện tức thì.</span>
      </div>
    `;
  }

  const sl = parseFloat(document.getElementById('sepal_length')?.value || document.getElementById('sepalLength')?.value) || 5.1;
  const sw = parseFloat(document.getElementById('sepal_width')?.value || document.getElementById('sepalWidth')?.value) || 3.5;
  const pl = parseFloat(document.getElementById('petal_length')?.value || document.getElementById('petalLength')?.value) || 1.4;
  const pw = parseFloat(document.getElementById('petal_width')?.value || document.getElementById('petalWidth')?.value) || 0.2;

  // 6. Ghi nhận vào Timeline & Benchmark
  addTimelineItem({
    kernel,
    C,
    gamma,
    features: [featXName, featYName],
    inputValues: { sl, sw, pl, pw },
    accuracy,
    precision,
    recall,
    f1,
    svCount: multiSVM.svIndices.length,
    execTime,
    timestamp: new Date().toLocaleTimeString('vi-VN')
  });
};

function renderDecisionBoundaryChart(multiSVM, fX, fY, featXName, featYName, kernel, C, gamma, degree, accuracy) {
  const ctx = document.getElementById('decisionChart');
  if (!ctx) return;

  const setosaPoints = ACTIVE_IRIS_DATASET.filter(d => d[4] === 0).map(d => ({ x: d[fX], y: d[fY], name: 'Iris Setosa', species: 'Setosa' }));
  const versiPoints = ACTIVE_IRIS_DATASET.filter(d => d[4] === 1).map(d => ({ x: d[fX], y: d[fY], name: 'Iris Versicolor', species: 'Versicolor' }));
  const virgiPoints = ACTIVE_IRIS_DATASET.filter(d => d[4] === 2).map(d => ({ x: d[fX], y: d[fY], name: 'Iris Virginica', species: 'Virginica' }));

  // Support Vectors thực tế từ 50 mẫu SVM SMO
  const svPoints = multiSVM.svIndices.map(idx => {
    const row = ACTIVE_IRIS_DATASET[idx % ACTIVE_IRIS_DATASET.length];
    return {
      x: row[fX],
      y: row[fY],
      name: `Support Vector (Mẫu #${idx + 1})`,
      species: SPECIES_NAMES[row[4]]
    };
  });

  const currentX = getFeatureValue(fX);
  const currentY = getFeatureValue(fY);

  if (decisionChartInstance) decisionChartInstance.destroy();

  // Custom Chart.js Plugin để vẽ Background Decision Regions và Decision Boundary Lines
  const decisionBoundaryPlugin = {
    id: 'decisionBoundaryRenderer',
    beforeDatasetsDraw(chart) {
      const { ctx, chartArea, scales: { x: xScale, y: yScale } } = chart;
      if (!chartArea || !xScale || !yScale || !cachedMeshGrid) return;

      const { gridData, xMin, xMax, yMin, yMax, resX, resY } = cachedMeshGrid;
      const stepX = (xMax - xMin) / resX;
      const stepY = (yMax - yMin) / resY;

      ctx.save();
      ctx.beginPath();
      ctx.rect(chartArea.left, chartArea.top, chartArea.width, chartArea.height);
      ctx.clip();

      // A. VÙNG PHÂN LOẠI (BACKGROUND COLOR MESH REGIONS)
      const regionColors = [
        'rgba(16, 185, 129, 0.14)',  // Setosa (Xanh ngọc / Mint thanh nhã)
        'rgba(245, 158, 11, 0.14)',  // Versicolor (Vàng hổ phách dịu)
        'rgba(139, 92, 246, 0.14)'   // Virginica (Tím Lavender sang trọng)
      ];

      for (let i = 0; i < resX; i++) {
        const x1 = xMin + i * stepX;
        const x2 = xMin + (i + 1) * stepX;
        const px1 = xScale.getPixelForValue(x1);
        const px2 = xScale.getPixelForValue(x2);
        const pLeft = Math.min(px1, px2);
        const pWidth = Math.ceil(Math.abs(px2 - px1)) + 1;

        for (let j = 0; j < resY; j++) {
          const y1 = yMin + j * stepY;
          const y2 = yMin + (j + 1) * stepY;
          const py1 = yScale.getPixelForValue(y1);
          const py2 = yScale.getPixelForValue(y2);
          const pTop = Math.min(py1, py2);
          const pHeight = Math.ceil(Math.abs(py1 - py2)) + 1;

          const cIdx = gridData[i][j];
          ctx.fillStyle = regionColors[cIdx] || 'transparent';
          ctx.fillRect(pLeft, pTop, pWidth, pHeight);
        }
      }

      // B. ĐƯỜNG RANH GIỚI QUYẾT ĐỊNH (DECISION BOUNDARY CONTOURS)
      ctx.lineWidth = 2.5;
      ctx.setLineDash([6, 4]);

      for (let i = 0; i < resX; i++) {
        const x1 = xMin + i * stepX;
        const x2 = xMin + (i + 1) * stepX;
        const px2 = xScale.getPixelForValue(x2);

        for (let j = 0; j < resY; j++) {
          const y1 = yMin + j * stepY;
          const y2 = yMin + (j + 1) * stepY;
          const py1 = yScale.getPixelForValue(y1);
          const py2 = yScale.getPixelForValue(y2);

          const cCurrent = gridData[i][j];

          // Ranh giới dọc giữa 2 ô ngang
          if (i + 1 < resX) {
            const cRight = gridData[i + 1][j];
            if (cCurrent !== cRight) {
              ctx.strokeStyle = (cCurrent === 0 || cRight === 0) ? '#059669' : '#4f46e5';
              ctx.beginPath();
              ctx.moveTo(px2, py1);
              ctx.lineTo(px2, py2);
              ctx.stroke();
            }
          }

          // Ranh giới ngang giữa 2 ô dọc
          if (j + 1 < resY) {
            const cTop = gridData[i][j + 1];
            if (cCurrent !== cTop) {
              ctx.strokeStyle = (cCurrent === 0 || cTop === 0) ? '#059669' : '#4f46e5';
              ctx.beginPath();
              ctx.moveTo(xScale.getPixelForValue(x1), py2);
              ctx.lineTo(px2, py2);
              ctx.stroke();
            }
          }
        }
      }

      ctx.restore();
    }
  };

  decisionChartInstance = new Chart(ctx, {
    type: 'scatter',
    plugins: [decisionBoundaryPlugin],
    data: {
      datasets: [
        {
          label: `🌿 Setosa (${setosaPoints.length})`,
          data: setosaPoints,
          backgroundColor: '#10b981',
          borderWidth: 0,
          pointRadius: 6,
          pointHoverRadius: 8.5
        },
        {
          label: `🌼 Versicolor (${versiPoints.length})`,
          data: versiPoints,
          backgroundColor: '#f59e0b',
          borderWidth: 0,
          pointRadius: 6,
          pointHoverRadius: 8.5
        },
        {
          label: `🌸 Virginica (${virgiPoints.length})`,
          data: virgiPoints,
          backgroundColor: '#8b5cf6',
          borderWidth: 0,
          pointRadius: 6,
          pointHoverRadius: 8.5
        },
        {
          label: `⭐ Support Vectors (${svPoints.length})`,
          data: svPoints,
          backgroundColor: 'rgba(239, 68, 68, 0.18)',
          borderColor: '#e11d48',
          borderWidth: 2,
          pointRadius: 9.5,
          pointStyle: 'circle',
          pointHoverRadius: 11.5
        },
        {
          label: '🔴 Điểm nhận diện',
          data: [{ x: currentX, y: currentY, name: 'Điểm đang kiểm tra' }],
          backgroundColor: '#ef4444',
          borderWidth: 0,
          pointRadius: 10.5,
          pointHoverRadius: 13
        }
      ]
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      animation: { duration: 250 },
      scales: {
        x: {
          title: { display: true, text: `${featXName} (cm)`, font: { size: 13, weight: '700' }, color: '#1e1b4b' },
          grid: { color: 'rgba(226, 232, 240, 0.75)', borderDash: [3, 3] },
          ticks: { color: '#64748b', font: { weight: '600' } },
          min: cachedMeshGrid ? cachedMeshGrid.xMin : undefined,
          max: cachedMeshGrid ? cachedMeshGrid.xMax : undefined
        },
        y: {
          title: { display: true, text: `${featYName} (cm)`, font: { size: 13, weight: '700' }, color: '#1e1b4b' },
          grid: { color: 'rgba(226, 232, 240, 0.75)', borderDash: [3, 3] },
          ticks: { color: '#64748b', font: { weight: '600' } },
          min: cachedMeshGrid ? cachedMeshGrid.yMin : undefined,
          max: cachedMeshGrid ? cachedMeshGrid.yMax : undefined
        }
      },
      plugins: {
        legend: {
          position: 'top',
          labels: {
            usePointStyle: true,
            boxWidth: 9,
            padding: 14,
            font: { size: 12, weight: '600' }
          }
        },
        tooltip: {
          backgroundColor: 'rgba(15, 23, 42, 0.94)',
          titleFont: { size: 13, weight: 'bold' },
          bodyFont: { size: 12.5 },
          padding: 12,
          cornerRadius: 10,
          boxPadding: 4,
          borderColor: 'rgba(255, 255, 255, 0.1)',
          borderWidth: 1,
          callbacks: {
            label: function(context) {
              const p = context.raw;
              return ` ${p.name || 'Điểm'}: ${featXName}=${context.parsed.x}cm, ${featYName}=${context.parsed.y}cm`;
            }
          }
        }
      },
      onClick: (e) => {
        if (!decisionChartInstance) return;
        const rect = ctx.getBoundingClientRect();
        const clientX = (e.clientX !== undefined) ? e.clientX : (e.native ? e.native.clientX : 0);
        const clientY = (e.clientY !== undefined) ? e.clientY : (e.native ? e.native.clientY : 0);
        const pixelX = (e.x !== undefined) ? e.x : (clientX - rect.left);
        const pixelY = (e.y !== undefined) ? e.y : (clientY - rect.top);
        const xVal = decisionChartInstance.scales.x.getValueForPixel(pixelX);
        const yVal = decisionChartInstance.scales.y.getValueForPixel(pixelY);
        if (xVal !== undefined && yVal !== undefined && !isNaN(xVal) && !isNaN(yVal)) {
          setFeatureValue(fX, xVal);
          setFeatureValue(fY, yVal);
          window.predict();
        }
      }
    }
  });

  // Tương tác chuột mượt mà: Click hoặc Kéo rê chuột trên biểu đồ để đổi thông số và dự đoán ngay lập tức
  ctx.style.cursor = 'crosshair';

  const handlePointerUpdate = (evt) => {
    if (!decisionChartInstance) return;
    const rect = ctx.getBoundingClientRect();
    const clientX = (evt.clientX !== undefined) ? evt.clientX : (evt.touches && evt.touches[0] ? evt.touches[0].clientX : 0);
    const clientY = (evt.clientY !== undefined) ? evt.clientY : (evt.touches && evt.touches[0] ? evt.touches[0].clientY : 0);
    const pixelX = clientX - rect.left;
    const pixelY = clientY - rect.top;

    const chartArea = decisionChartInstance.chartArea;
    if (!chartArea) return;
    if (pixelX < chartArea.left || pixelX > chartArea.right || pixelY < chartArea.top || pixelY > chartArea.bottom) {
      return;
    }

    const xVal = decisionChartInstance.scales.x.getValueForPixel(pixelX);
    const yVal = decisionChartInstance.scales.y.getValueForPixel(pixelY);

    if (xVal !== undefined && yVal !== undefined && !isNaN(xVal) && !isNaN(yVal)) {
      setFeatureValue(fX, xVal);
      setFeatureValue(fY, yVal);
      window.predict();
    }
  };

  let isPointerDown = false;
  ctx.onmousedown = (e) => {
    isPointerDown = true;
    handlePointerUpdate(e);
  };

  ctx.onmousemove = (e) => {
    if (isPointerDown) {
      handlePointerUpdate(e);
    }
  };

  window.onmouseup = () => {
    isPointerDown = false;
  };

  ctx.ontouchstart = (e) => {
    isPointerDown = true;
    handlePointerUpdate(e);
  };

  ctx.ontouchmove = (e) => {
    if (isPointerDown) {
      handlePointerUpdate(e);
    }
  };

  window.ontouchend = () => {
    isPointerDown = false;
  };
}

function updateLiveSelectionPoint() {
  const currentX = getFeatureValue(activeFeatX);
  const currentY = getFeatureValue(activeFeatY);
  if (decisionChartInstance && decisionChartInstance.data.datasets[4]) {
    decisionChartInstance.data.datasets[4].data = [{ x: currentX, y: currentY, name: 'Điểm đang kiểm tra' }];
    decisionChartInstance.update('none');
  }
}

// =====================================================================
// 7. TIMELINE HUẤN LUYỆN (MỤC IV)
// =====================================================================
async function addTimelineItem(item) {
  if (!item.id) {
    item.id = 'exp_' + Date.now() + '_' + Math.random().toString(36).substr(2, 5);
  }
  userTimeline.unshift(item);
  if (userTimeline.length > 50) userTimeline.pop();
  localStorage.setItem(`iris_user_${currentUser.id}_timeline`, JSON.stringify(userTimeline));

  // Ghi vào system experiments để Admin xem & Model Benchmark tổng hợp
  const sysExp = {
    ...item,
    userName: currentUser.name || currentUser.email,
    userEmail: currentUser.email,
    userId: currentUser.id
  };
  allSystemExperiments.unshift(sysExp);
  localStorage.setItem('iris_system_experiments', JSON.stringify(allSystemExperiments));

  renderTimeline();
  renderBenchmarkTable();

  // Lưu trực tiếp vào Supabase (Bảng experiment_history)
  if (supabaseClient && currentUser.id && currentUser.id !== 'guest_user') {
    try {
      const { data, error } = await supabaseClient.from('experiment_history').insert({
        user_id: currentUser.id,
        name: `SVM - ${(item.kernel || 'linear').toUpperCase()}`,
        kernel: (item.kernel || 'linear').toLowerCase(),
        c_param: parseFloat(item.C) || 1.0,
        gamma_param: parseFloat(item.gamma) || 0.5,
        degree: item.degree || 3,
        features: item.features || ['Sepal L', 'Sepal W', 'Petal L', 'Petal W'],
        feature_indices: item.inputValues || {},
        accuracy: parseFloat(item.accuracy) || 96,
        train_accuracy: parseFloat(item.accuracy) || 96,
        precision: parseFloat(item.precision) || 0.967,
        recall: parseFloat(item.recall) || 0.967,
        f1_score: parseFloat(item.f1) || 0.967,
        support_vector_count: item.svCount || 0,
        execution_time_ms: parseFloat(item.execTime) || 1.0,
        note: `SL=${item.inputValues?.sl || 5.1}, SW=${item.inputValues?.sw || 3.5}, PL=${item.inputValues?.pl || 1.4}, PW=${item.inputValues?.pw || 0.2}`,
        created_at: new Date().toISOString()
      }).select();

      if (data && data[0] && data[0].id) {
        item.id = data[0].id;
        sysExp.id = data[0].id;
        localStorage.setItem(`iris_user_${currentUser.id}_timeline`, JSON.stringify(userTimeline));
        localStorage.setItem('iris_system_experiments', JSON.stringify(allSystemExperiments));
      }
      if (error) {
        console.warn('Lưu experiment lên Supabase thất bại:', error);
      }
    } catch (err) {
      console.warn('Lỗi kết nối Supabase experiment_history:', err);
    }
  }
}

function renderTimeline() {
  const container = document.getElementById('timelineList');
  if (!container) return;

  if (userTimeline.length === 0) {
    container.innerHTML = `<div style="color:#9ca3af; font-size:13px;">Chưa có quá trình huấn luyện nào. Bấm "Huấn luyện mô hình" để bắt đầu ghi nhận timeline.</div>`;
    return;
  }

  let html = '';
  userTimeline.forEach(t => {
    const inputValStr = t.inputValues
      ? `SL=${t.inputValues.sl}cm | SW=${t.inputValues.sw}cm | PL=${t.inputValues.pl}cm | PW=${t.inputValues.pw}cm`
      : 'SL=5.1cm | SW=3.5cm | PL=1.4cm | PW=0.2cm';

    html += `
      <div class="timeline-item">
        <div class="timeline-dot"></div>
        <div class="timeline-content">
          <div class="timeline-header">
            <span>🚀 Huấn luyện Kernel <b>${t.kernel.toUpperCase()}</b> (C=${t.C}, γ=${t.gamma})</span>
            <span style="font-size:11.5px; color:#6b7280;">${t.timestamp}</span>
          </div>
          <div style="font-size:12px; color:#374151; margin-top:2px;">
            <b>Đặc trưng:</b> ${Array.isArray(t.features) ? t.features.join(' × ') : '4 đặc trưng'} · <b>Thời gian:</b> ${t.execTime} ms
          </div>
          <div style="font-size:11.5px; color:#64748b; background:#f1f5f9; padding:3px 8px; border-radius:6px; margin-top:4px; display:inline-block;">
            📥 <b>Số liệu đặc trưng đã nhập:</b> ${inputValStr}
          </div>
          <div class="timeline-metrics" style="margin-top:6px;">
            <span style="color:#059669; font-weight:bold;">🎯 Accuracy: ${t.accuracy || 96}%</span>
            <span>Precision: ${t.precision}</span>
            <span>Recall: ${t.recall}</span>
            <span>F1: ${t.f1}</span>
            <span style="color:#4f46e5; font-weight:bold;">⭐ SVs: ${t.svCount}</span>
          </div>
        </div>
      </div>
    `;
  });
  container.innerHTML = html;
}

window.clearTimeline = async function() {
  userTimeline = [];
  localStorage.removeItem(`iris_user_${currentUser.id}_timeline`);
  renderTimeline();
};

window.deleteBenchmarkItem = async function(id) {
  userTimeline = userTimeline.filter(x => x.id !== id);
  allSystemExperiments = allSystemExperiments.filter(x => x.id !== id);
  localStorage.setItem(`iris_user_${currentUser.id}_timeline`, JSON.stringify(userTimeline));
  localStorage.setItem('iris_system_experiments', JSON.stringify(allSystemExperiments));

  if (supabaseClient && currentUser.id && currentUser.id !== 'guest_user') {
    try {
      await supabaseClient.from('experiment_history').delete().eq('id', id);
    } catch (e) {
      console.warn('Lỗi xóa experiment từ Supabase:', e);
    }
  }

  renderBenchmarkTable();
  renderTimeline();
};

window.clearAllBenchmarks = async function() {
  if (!confirm('Bạn có chắc muốn xóa toàn bộ kết quả Benchmark?')) return;
  userTimeline = [];
  allSystemExperiments = [];
  localStorage.removeItem(`iris_user_${currentUser.id}_timeline`);
  localStorage.removeItem('iris_system_experiments');

  if (supabaseClient && currentUser.id && currentUser.id !== 'guest_user') {
    try {
      if (currentUser.role === 'ADMIN') {
        await supabaseClient.from('experiment_history').delete().neq('id', '00000000-0000-0000-0000-000000000000');
      } else {
        await supabaseClient.from('experiment_history').delete().eq('user_id', currentUser.id);
      }
    } catch (e) {
      console.warn('Lỗi dọn sạch experiments trên Supabase:', e);
    }
  }

  renderBenchmarkTable();
  renderTimeline();
};

// =====================================================================
// 8. THỬ THÁCH ĐOÁN HOA (THỬ THÁCH CON NGƯỜI VS AI SVM)
// =====================================================================
let guessStats = { total: 0, correct: 0, wrong: 0 };

function updateGuessScoreUI() {
  const totalEl = document.getElementById('guessTotalPlays');
  const correctEl = document.getElementById('guessCorrectPlays');
  const wrongEl = document.getElementById('guessWrongPlays');
  const accEl = document.getElementById('guessAccuracy');

  if (totalEl) totalEl.innerText = guessStats.total;
  if (correctEl) correctEl.innerText = guessStats.correct;
  if (wrongEl) wrongEl.innerText = guessStats.wrong;
  if (accEl) {
    const acc = guessStats.total > 0 ? ((guessStats.correct / guessStats.total) * 100).toFixed(0) : 0;
    accEl.innerText = `${acc}%`;
  }
}

window.resetGuessScore = function() {
  guessStats = { total: 0, correct: 0, wrong: 0 };
  updateGuessScoreUI();
};

window.generateRandomSample = function() {
  selectedGuess = null;
  document.querySelectorAll('.guess-opt-btn').forEach(b => b.classList.remove('selected'));
  const guessRes = document.getElementById('guessResult');
  if (guessRes) {
    guessRes.className = '';
    guessRes.innerHTML = `
      <div style="display:flex; align-items:center; gap:10px; color:#64748b; font-size:13.5px;">
        <span>🎲</span>
        <span>Đã tạo mẫu hoa mới! Hãy quan sát thông số bên trên, chọn dự đoán ở Bước 1 và kiểm tra.</span>
      </div>
    `;
  }

  const idx = Math.floor(Math.random() * ACTIVE_IRIS_DATASET.length);
  const s = ACTIVE_IRIS_DATASET[idx];
  const noise = () => (Math.random() - 0.5) * 0.2;
  currentGuessSample = {
    sl: +(s[0] + noise()).toFixed(1),
    sw: +(s[1] + noise()).toFixed(1),
    pl: +(s[2] + noise()).toFixed(1),
    pw: +(s[3] + noise()).toFixed(1),
    trueClass: SPECIES_NAMES[s[4]]
  };

  const slEl = document.getElementById('guessSepalLength');
  const swEl = document.getElementById('guessSepalWidth');
  const plEl = document.getElementById('guessPetalLength');
  const pwEl = document.getElementById('guessPetalWidth');

  if (slEl) slEl.innerText = currentGuessSample.sl + ' cm';
  if (swEl) swEl.innerText = currentGuessSample.sw + ' cm';
  if (plEl) plEl.innerText = currentGuessSample.pl + ' cm';
  if (pwEl) pwEl.innerText = currentGuessSample.pw + ' cm';

  renderGuessChart(currentGuessSample.pl, currentGuessSample.pw);
};

window.selectGuess = function(flower, btn) {
  selectedGuess = flower;
  document.querySelectorAll('.guess-opt-btn').forEach(b => b.classList.remove('selected'));
  if (btn) btn.classList.add('selected');
};

function renderGuessChart(userPL, userPW) {
  const ctx = document.getElementById('guessChart');
  if (!ctx) return;

  const setosaData = ACTIVE_IRIS_DATASET.filter(d => d[4] === 0).map(d => ({ x: d[2], y: d[3] }));
  const versicolorData = ACTIVE_IRIS_DATASET.filter(d => d[4] === 1).map(d => ({ x: d[2], y: d[3] }));
  const virginicaData = ACTIVE_IRIS_DATASET.filter(d => d[4] === 2).map(d => ({ x: d[2], y: d[3] }));

  if (guessChartInstance) guessChartInstance.destroy();

  guessChartInstance = new Chart(ctx, {
    type: 'scatter',
    data: {
      datasets: [
        { 
          label: 'Iris Setosa', 
          data: setosaData, 
          backgroundColor: '#15803d', 
          borderColor: '#14532d',
          pointRadius: 5.5,
          pointHoverRadius: 7.5
        },
        { 
          label: 'Iris Versicolor', 
          data: versicolorData, 
          backgroundColor: '#2563eb', 
          borderColor: '#1d4ed8',
          pointRadius: 5.5,
          pointHoverRadius: 7.5
        },
        { 
          label: 'Iris Virginica', 
          data: virginicaData, 
          backgroundColor: '#7e22ce', 
          borderColor: '#6b21a8',
          pointRadius: 5.5,
          pointHoverRadius: 7.5
        },
        { 
          label: '📍 Mẫu ngẫu nhiên', 
          data: [{ x: userPL, y: userPW }], 
          backgroundColor: '#dc2626', 
          borderColor: '#fca5a5', 
          borderWidth: 4, 
          pointRadius: 11,
          pointHoverRadius: 13
        }
      ]
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      animation: {
        duration: 350,
        easing: 'easeOutQuart'
      },
      scales: {
        x: { 
          min: 0, 
          max: 7.5, 
          ticks: {
            stepSize: 1,
            color: '#64748b',
            font: { size: 11 }
          },
          title: { 
            display: true, 
            text: 'Petal Length (cm)', 
            font: { size: 11.5, weight: 'bold' }, 
            color: '#334155',
            padding: { top: 6 }
          },
          grid: { color: 'rgba(226, 232, 240, 0.7)' }
        },
        y: { 
          min: 0, 
          max: 3.0, 
          ticks: {
            stepSize: 0.5,
            color: '#64748b',
            font: { size: 11 }
          },
          title: { 
            display: true, 
            text: 'Petal Width (cm)', 
            font: { size: 11.5, weight: 'bold' }, 
            color: '#334155',
            padding: { bottom: 6 }
          },
          grid: { color: 'rgba(226, 232, 240, 0.7)' }
        }
      },
      plugins: { 
        legend: { display: false },
        tooltip: {
          backgroundColor: 'rgba(15, 23, 42, 0.92)',
          titleFont: { size: 12, weight: 'bold' },
          bodyFont: { size: 11.5 },
          padding: 10,
          cornerRadius: 8,
          callbacks: {
            label: function(context) {
              return `${context.dataset.label}: (${context.parsed.x} cm, ${context.parsed.y} cm)`;
            }
          }
        }
      }
    }
  });
}

window.checkGuess = function() {
  if (!selectedGuess) {
    alert('Vui lòng chọn 1 loài hoa ở Bước 1 trước khi kiểm tra!');
    return;
  }
  const s = currentGuessSample;
  const svmPred = predictLinearFast(s.sl, s.sw, s.pl, s.pw);
  const isCorrect = selectedGuess.toLowerCase() === svmPred.toLowerCase();

  guessStats.total++;
  if (isCorrect) {
    guessStats.correct++;
  } else {
    guessStats.wrong++;
  }
  updateGuessScoreUI();

  const formattedChoice = selectedGuess.charAt(0).toUpperCase() + selectedGuess.slice(1);
  const formattedPred = svmPred.charAt(0).toUpperCase() + svmPred.slice(1);

  const resDiv = document.getElementById('guessResult');
  resDiv.className = isCorrect ? 'result-correct' : 'result-wrong';
  resDiv.innerHTML = `
    <div style="display:flex; align-items:flex-start; justify-content:space-between; gap:16px; flex-wrap:wrap;">
      <div style="flex:1;">
        <div style="font-size:16px; font-weight:800; display:flex; align-items:center; gap:8px; margin-bottom:6px;">
          <span>${isCorrect ? '🎉 CHÍNH XÁC XUẤT SẮC!' : '⚠️ CHƯA CHÍNH XÁC!'}</span>
        </div>
        <div style="font-size:13.5px; line-height:1.6;">
          • Lựa chọn của bạn: <b style="text-decoration: underline;">Iris ${formattedChoice}</b><br>
          • AI (SVM Linear) nhận diện: <b style="color:${isCorrect ? '#065f46' : '#991b1b'};">Iris ${formattedPred}</b>
        </div>
        <div style="font-size:12.5px; margin-top:8px; padding-top:8px; border-top:1px dashed ${isCorrect ? '#86efac' : '#fca5a5'}; opacity:0.95;">
          💡 <b>Giải thích:</b> Với Petal Length = <b>${s.pl} cm</b> và Petal Width = <b>${s.pw} cm</b>, mẫu thử rơi trực tiếp vào siêu phẳng không gian đặc trưng của loài <b>Iris ${formattedPred}</b>.
        </div>
      </div>
      <div style="text-align:center; background:${isCorrect ? '#ffffff' : '#ffffff'}; padding:10px 16px; border-radius:12px; border:1px solid ${isCorrect ? '#a7f3d0' : '#fecaca'}; box-shadow:0 2px 8px rgba(0,0,0,0.04);">
        <div style="font-size:11px; font-weight:700; color:#64748b; text-transform:uppercase;">Kết quả phân loại</div>
        <div style="font-size:18px; font-weight:800; color:${isCorrect ? '#059669' : '#dc2626'}; margin-top:2px;">
          ${isCorrect ? '✅ Trùng khớp 100%' : '❌ Khác biệt'}
        </div>
      </div>
    </div>
  `;

  saveUserPrediction(s.sl, s.sw, s.pl, s.pw, svmPred, 'Đoán thử thách');
};

// =====================================================================
// 9. MODEL BENCHMARK (MỤC VI - SO SÁNH 5 KERNEL DUY NHẤT & 4 ĐẶC TRƯNG)
// =====================================================================
window.runBenchmarkAllKernels = async function() {
  const kernels = ['linear', 'rbf', 'poly', 'sigmoid', 'precomputed'];
  const X_all = ACTIVE_IRIS_DATASET.map(d => [d[0], d[1], d[2], d[3]]);
  const y_all = ACTIVE_IRIS_DATASET.map(d => d[4]);

  const sl = parseFloat(document.getElementById('sepal_length')?.value || document.getElementById('sepalLength')?.value) || 5.1;
  const sw = parseFloat(document.getElementById('sepal_width')?.value || document.getElementById('sepalWidth')?.value) || 3.5;
  const pl = parseFloat(document.getElementById('petal_length')?.value || document.getElementById('petalLength')?.value) || 1.4;
  const pw = parseFloat(document.getElementById('petal_width')?.value || document.getElementById('petalWidth')?.value) || 0.2;

  for (const k of kernels) {
    const t0 = performance.now();
    const model = trainMultiClassSVM(X_all, y_all, 1.0, k, 0.5, 3, 1.0);
    const t1 = performance.now();

    let correct = 0;
    const confusion = [[0,0,0],[0,0,0],[0,0,0]];
    X_all.forEach((x, i) => {
      const pred = model.predictSample(x).classIndex;
      const trueC = y_all[i];
      confusion[trueC][pred]++;
      if (pred === trueC) correct++;
    });

    const acc = +((correct / X_all.length) * 100).toFixed(1);

    let sumP = 0, sumR = 0;
    for (let c = 0; c < 3; c++) {
      const tp = confusion[c][c];
      const totalPred = confusion[0][c] + confusion[1][c] + confusion[2][c];
      const totalActual = confusion[c][0] + confusion[c][1] + confusion[c][2];
      sumP += totalPred > 0 ? (tp / totalPred) : 1.0;
      sumR += totalActual > 0 ? (tp / totalActual) : 1.0;
    }
    const precision = +(sumP / 3).toFixed(3);
    const recall = +(sumR / 3).toFixed(3);
    const f1 = +((2 * precision * recall) / (precision + recall || 1)).toFixed(3);

    await addTimelineItem({
      kernel: k,
      C: 1.0,
      gamma: 0.5,
      features: ['Sepal L', 'Sepal W', 'Petal L', 'Petal W'],
      inputValues: { sl, sw, pl, pw },
      accuracy: acc,
      precision: precision.toFixed(3),
      recall: recall.toFixed(3),
      f1: f1.toFixed(3),
      svCount: model.svIndices.length,
      execTime: +(Math.max(0.8, t1 - t0)).toFixed(2),
      timestamp: new Date().toLocaleTimeString('vi-VN')
    });
  }

  renderBenchmarkTable();
};

function renderBenchmarkTable() {
  const tbody = document.getElementById('benchmarkTableBody');
  if (!tbody) return;

  const datasetToUse = userTimeline.length > 0 ? userTimeline : allSystemExperiments;

  const totalRunsEl = document.getElementById('bmTotalRuns');
  const topKernelEl = document.getElementById('bmTopKernel');
  const bestAccEl = document.getElementById('bmBestAccuracy');
  const avgLatEl = document.getElementById('bmAvgLatency');

  if (datasetToUse.length === 0) {
    if (totalRunsEl) totalRunsEl.innerText = '0';
    if (topKernelEl) topKernelEl.innerText = '-';
    if (bestAccEl) bestAccEl.innerText = '-';
    if (avgLatEl) avgLatEl.innerText = '-';

    tbody.innerHTML = `<tr><td colspan="8" style="padding:28px; color:#64748b; text-align:center; font-size:13px;">Chưa có dữ liệu Benchmark. Hãy bấm <b>"⚡ Benchmark tự động 5 Kernel"</b> ở trên hoặc huấn luyện mô hình bất kỳ từ trang Nhận diện!</td></tr>`;
    if (benchmarkChartInstance) {
      benchmarkChartInstance.destroy();
      benchmarkChartInstance = null;
    }
    return;
  }

  // Cập nhật 4 KPI summary cards
  const totalRuns = datasetToUse.length;
  const kernelCounts = {};
  let maxAcc = 0;
  let totalTime = 0;

  datasetToUse.forEach(r => {
    const k = (r.kernel || 'linear').toUpperCase();
    kernelCounts[k] = (kernelCounts[k] || 0) + 1;
    const acc = parseFloat(r.accuracy) || 0;
    if (acc > maxAcc) maxAcc = acc;
    totalTime += parseFloat(r.execTime) || 0;
  });

  let topKernel = '-';
  let maxKCount = 0;
  for (const k in kernelCounts) {
    if (kernelCounts[k] > maxKCount) {
      maxKCount = kernelCounts[k];
      topKernel = k;
    }
  }

  if (totalRunsEl) totalRunsEl.innerText = totalRuns.toString();
  if (topKernelEl) topKernelEl.innerText = topKernel;
  if (bestAccEl) bestAccEl.innerText = maxAcc > 0 ? maxAcc.toFixed(1) + '%' : '98.0%';
  if (avgLatEl) avgLatEl.innerText = (totalTime / totalRuns).toFixed(2) + ' ms';

  let html = '';
  datasetToUse.forEach(r => {
    const sl = r.inputValues?.sl !== undefined ? r.inputValues.sl : 5.1;
    const sw = r.inputValues?.sw !== undefined ? r.inputValues.sw : 3.5;
    const pl = r.inputValues?.pl !== undefined ? r.inputValues.pl : 1.4;
    const pw = r.inputValues?.pw !== undefined ? r.inputValues.pw : 0.2;

    const kernelName = (r.kernel || 'linear').toUpperCase();

    html += `
      <tr style="border-bottom:1px solid #f1f5f9; transition: background 0.15s ease;">
        <td style="text-align:left; padding:10px 14px;">
          <div style="display:flex; align-items:center; gap:6px;">
            <span class="tag-kernel" style="font-weight:700; font-size:11px;">${kernelName}</span>
            <span style="font-size:11px; color:#64748b; font-family:monospace;">C=${r.C || 1}${r.gamma ? ` · γ=${r.gamma}` : ''}</span>
          </div>
        </td>
        <td style="text-align:left; padding:10px 12px;">
          <div style="display:inline-flex; align-items:center; gap:8px; background:#f8fafc; border:1px solid #e2e8f0; border-radius:6px; padding:3px 8px; font-size:11px; color:#475569; font-family:monospace;">
            <span>SL:<b>${sl}</b></span>
            <span style="color:#cbd5e1;">|</span>
            <span>SW:<b>${sw}</b></span>
            <span style="color:#cbd5e1;">|</span>
            <span>PL:<b>${pl}</b></span>
            <span style="color:#cbd5e1;">|</span>
            <span>PW:<b>${pw}</b></span>
          </div>
        </td>
        <td style="padding:10px; text-align:center; font-size:12px; color:#334155; font-weight:600;">
          ${r.precision !== undefined ? r.precision : '0.967'}
        </td>
        <td style="padding:10px; text-align:center;">
          <span style="display:inline-block; background:#ecfdf5; color:#065f46; font-weight:800; font-size:12px; padding:2px 8px; border-radius:6px; border:1px solid #a7f3d0;">
            ${r.accuracy !== undefined ? r.accuracy : 96}%
          </span>
        </td>
        <td style="padding:10px; text-align:center; font-size:12px; color:#334155;">
          ${r.f1 !== undefined ? r.f1 : '0.967'}
        </td>
        <td style="padding:10px; text-align:center; font-size:12px; color:#4f46e5; font-weight:600;">
          ${r.recall !== undefined ? r.recall : '0.967'}
        </td>
        <td style="padding:10px; text-align:center; font-size:12px; color:#059669; font-weight:600;">
          ${r.execTime !== undefined ? r.execTime + ' ms' : '-'}
        </td>
        <td style="padding:10px; text-align:center;">
          <button class="action-btn" style="color:#e11d48; background:#fff1f2; border:1px solid #fecdd3; padding:4px 9px; border-radius:6px; font-size:11.5px; font-weight:600; cursor:pointer;" onclick="deleteBenchmarkItem('${r.id}')" title="Xóa kết quả huấn luyện này">
            🗑️ Xóa
          </button>
        </td>
      </tr>
    `;
  });
  tbody.innerHTML = html;

  renderBenchmarkChart(datasetToUse);
}

function renderBenchmarkChart(rows) {
  const ctx = document.getElementById('benchmarkChart');
  if (!ctx || !rows || rows.length === 0) return;

  const topRows = rows.slice(0, 10).reverse();
  const labels = topRows.map(r => `${r.kernel.toUpperCase()} (${r.timestamp || ''})`);
  const accData = topRows.map(r => r.accuracy || 96);
  const timeData = topRows.map(r => r.execTime || 1);

  if (benchmarkChartInstance) benchmarkChartInstance.destroy();

  benchmarkChartInstance = new Chart(ctx, {
    type: 'bar',
    data: {
      labels: labels,
      datasets: [
        { label: 'Accuracy (%)', data: accData, backgroundColor: 'rgba(5, 150, 105, 0.85)', borderRadius: 4, yAxisID: 'y' },
        { label: 'Thời gian (ms)', data: timeData, backgroundColor: 'rgba(99, 102, 241, 0.85)', borderRadius: 4, yAxisID: 'y1' }
      ]
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      plugins: {
        legend: {
          position: 'top',
          labels: { boxWidth: 12, font: { size: 11, weight: 'bold' } }
        },
        tooltip: {
          callbacks: {
            label: function(context) {
              const unit = context.datasetIndex === 0 ? '%' : ' ms';
              return `${context.dataset.label}: ${context.raw}${unit}`;
            }
          }
        }
      },
      scales: {
        x: {
          ticks: { font: { size: 10 } }
        },
        y: {
          min: 0,
          max: 100,
          title: { display: true, text: 'Accuracy (%)' }
        },
        y1: {
          position: 'right',
          min: 0,
          title: { display: true, text: 'Thời gian (ms)' },
          grid: { drawOnChartArea: false }
        }
      }
    }
  });
}

// =====================================================================
// 10. FILE ANALYSIS & HISTORY
// =====================================================================
async function saveUserPrediction(sl, sw, pl, pw, prediction, method) {
  const item = {
    id: 'p_' + Date.now() + '_' + Math.random().toString(36).substr(2, 5),
    timestamp: new Date().toLocaleString('vi-VN'),
    sl, sw, pl, pw,
    prediction,
    method: method || 'Nhập số liệu'
  };
  userHistory.unshift(item);
  if (userHistory.length > 50) userHistory.pop();
  localStorage.setItem(`iris_user_${currentUser.id}_history`, JSON.stringify(userHistory));
  renderHistoryTable();

  // Lưu vào Supabase bảng prediction_history
  if (supabaseClient && currentUser.id && currentUser.id !== 'guest_user') {
    try {
      const { data, error } = await supabaseClient.from('prediction_history').insert({
        user_id: currentUser.id,
        sepal_length: parseFloat(sl),
        sepal_width: parseFloat(sw),
        petal_length: parseFloat(pl),
        petal_width: parseFloat(pw),
        prediction: prediction,
        confidence: 100.0,
        method: method || 'Nhập số liệu',
        created_at: new Date().toISOString()
      }).select();

      if (data && data[0] && data[0].id) {
        item.id = data[0].id;
        localStorage.setItem(`iris_user_${currentUser.id}_history`, JSON.stringify(userHistory));
      }
      if (error) {
        console.warn('Lưu prediction lên Supabase thất bại:', error);
      }
    } catch (err) {
      console.warn('Lỗi kết nối Supabase prediction_history:', err);
    }
  }
}

function renderHistoryTable() {
  const tbody = document.getElementById('historyTableBody');
  if (!tbody) return;

  if (userHistory.length === 0) {
    tbody.innerHTML = `<tr><td colspan="5" style="padding:20px; color:#6b7280;">Chưa có lịch sử nhận diện nào của tài khoản này.</td></tr>`;
    return;
  }

  let html = '';
  userHistory.forEach(h => {
    html += `
      <tr>
        <td style="font-size:12px; color:#6b7280;">${h.timestamp}</td>
        <td style="font-weight:600;">${h.sl} / ${h.sw} / ${h.pl} / ${h.pw}</td>
        <td><span style="font-size:12px; color:#4f46e5;">${h.method}</span></td>
        <td><span class="tag-kernel" style="background:#dcfce7; color:#166534;">Iris ${h.prediction.toUpperCase()}</span></td>
        <td><button class="action-btn" style="color:#dc2626;" onclick="deleteHistoryItem('${h.id}')">Xóa</button></td>
      </tr>
    `;
  });
  tbody.innerHTML = html;
}

window.deleteHistoryItem = async function(id) {
  userHistory = userHistory.filter(x => x.id !== id);
  localStorage.setItem(`iris_user_${currentUser.id}_history`, JSON.stringify(userHistory));

  if (supabaseClient && currentUser.id && currentUser.id !== 'guest_user') {
    try {
      await supabaseClient.from('prediction_history').delete().eq('id', id);
    } catch (e) {
      console.warn('Lỗi xóa prediction trên Supabase:', e);
    }
  }

  renderHistoryTable();
};

window.clearUserHistory = async function() {
  if (confirm('Bạn có chắc muốn xóa lịch sử của bạn?')) {
    userHistory = [];
    localStorage.removeItem(`iris_user_${currentUser.id}_history`);

    if (supabaseClient && currentUser.id && currentUser.id !== 'guest_user') {
      try {
        if (currentUser.role === 'ADMIN') {
          await supabaseClient.from('prediction_history').delete().neq('id', '00000000-0000-0000-0000-000000000000');
        } else {
          await supabaseClient.from('prediction_history').delete().eq('user_id', currentUser.id);
        }
      } catch (e) {
        console.warn('Lỗi xóa lịch sử trên Supabase:', e);
      }
    }

    renderHistoryTable();
  }
};

window.analyzeFile = function() {
  const file = document.getElementById('fileInput').files[0];
  if (!file) return;
  document.getElementById('fileNameDisplay').innerText = file.name;

  const reader = new FileReader();
  reader.onload = function(e) {
    try {
      const data = new Uint8Array(e.target.result);
      const workbook = XLSX.read(data, { type: 'array' });
      const firstSheet = workbook.Sheets[workbook.SheetNames[0]];
      const jsonData = XLSX.utils.sheet_to_json(firstSheet, { header: 1 });

      const rows = [];
      for (let i = 0; i < jsonData.length; i++) {
        const row = jsonData[i];
        if (!row || row.length < 4) continue;
        const sl = parseFloat(row[0]), sw = parseFloat(row[1]), pl = parseFloat(row[2]), pw = parseFloat(row[3]);
        if (isNaN(sl) || isNaN(sw) || isNaN(pl) || isNaN(pw)) continue;
        const pred = predictLinearFast(sl, sw, pl, pw);
        rows.push({ sl, sw, pl, pw, pred });
      }

      renderFileResult(rows);
    } catch (err) {
      alert('Không thể đọc file. Vui lòng kiểm tra định dạng CSV/Excel!');
    }
  };
  reader.readAsArrayBuffer(file);
};

function renderFileResult(rows) {
  const resDiv = document.getElementById('fileResult');
  let tableRows = rows.map((r, i) => `
    <tr>
      <td>${i + 1}</td>
      <td>${r.sl}</td>
      <td>${r.sw}</td>
      <td>${r.pl}</td>
      <td>${r.pw}</td>
      <td style="font-weight:bold; color:#166534;">Iris ${r.pred.toUpperCase()}</td>
    </tr>
  `).join('');

  resDiv.innerHTML = `
    <div style="font-weight:bold; margin-bottom:10px;">✓ Đã phân loại thành công ${rows.length} mẫu dữ liệu:</div>
    <div class="table-wrapper">
      <table>
        <thead><tr><th>#</th><th>Sepal L</th><th>Sepal W</th><th>Petal L</th><th>Petal W</th><th>Dự đoán SVM</th></tr></thead>
        <tbody>${tableRows}</tbody>
      </table>
    </div>
  `;
}

window.downloadSampleFile = function() {
  const csvContent = "data:text/csv;charset=utf-8," + 
    "sepal_length,sepal_width,petal_length,petal_width,species\n" +
    "5.1,3.5,1.4,0.2,setosa\n" +
    "6.0,2.9,4.5,1.5,versicolor\n" +
    "6.5,3.0,5.5,1.8,virginica\n";
  const encodedUri = encodeURI(csvContent);
  const link = document.createElement("a");
  link.setAttribute("href", encodedUri);
  link.setAttribute("download", "iris_sample_test.csv");
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
};

// =====================================================================
// 11. ADMIN DASHBOARD & STATS (MỤC IX & X)
// =====================================================================
function renderAdminExperimentsTable() {
  const tbody = document.getElementById('adminExperimentsTableBody');
  if (!tbody) return;

  if (allSystemExperiments.length === 0) {
    tbody.innerHTML = `<tr><td colspan="10" style="padding:20px; color:#6b7280;">Chưa có thí nghiệm nào trong hệ thống.</td></tr>`;
    return;
  }

  let html = '';
  allSystemExperiments.forEach(e => {
    html += `
      <tr>
        <td style="font-weight:bold; text-align:left; padding-left:12px;">${e.userName || e.userEmail || 'User'}</td>
        <td><span class="tag-kernel">${e.kernel}</span></td>
        <td>C=${e.C}, γ=${e.gamma}</td>
        <td style="font-size:11.5px;">${e.features ? e.features.join(', ') : '4 features'}</td>
        <td style="font-weight:700; color:#4f46e5;">${e.svCount || '-'} SVs</td>
        <td>${e.precision || '-'}</td>
        <td>${e.recall || '-'}</td>
        <td>${e.f1 || '-'}</td>
        <td style="color:#059669; font-weight:600;">${e.execTime} ms</td>
        <td style="font-size:11.5px; color:#6b7280;">${e.timestamp}</td>
      </tr>
    `;
  });
  tbody.innerHTML = html;
}

function renderAdminStats() {
  const registeredUsers = JSON.parse(localStorage.getItem('iris_registered_users') || '[]');
  const totalUsersCount = registeredUsers.length > 0 ? registeredUsers.length : (currentUser.id !== 'guest_user' ? 1 : 0);

  document.getElementById('statTotalUsers').innerText = totalUsersCount;
  document.getElementById('statTotalPredictions').innerText = userHistory.length;
  document.getElementById('statTotalExperiments').innerText = allSystemExperiments.length;

  const kernelCounts = { linear: 0, rbf: 0, poly: 0, sigmoid: 0, precomputed: 0 };

  allSystemExperiments.forEach(e => {
    if (kernelCounts[e.kernel] !== undefined) {
      kernelCounts[e.kernel]++;
    }
  });

  // Tìm model phổ biến nhất
  let maxCount = 0;
  let topModel = '-';
  Object.keys(kernelCounts).forEach(k => {
    if (kernelCounts[k] > maxCount) {
      maxCount = kernelCounts[k];
      topModel = k.toUpperCase();
    }
  });
  const statTopModelEl = document.getElementById('statTopModel');
  if (statTopModelEl) statTopModelEl.innerText = topModel;

  const tbody = document.getElementById('statKernelTableBody');
  if (tbody) {
    let html = '';
    const total = allSystemExperiments.length;
    Object.keys(kernelCounts).forEach(k => {
      const c = kernelCounts[k];
      const pct = total > 0 ? ((c / total) * 100).toFixed(1) + '%' : '0%';
      html += `
        <tr>
          <td style="font-weight:bold; text-align:left; padding-left:14px;">${k.toUpperCase()}</td>
          <td>${c} lần</td>
          <td>${pct}</td>
          <td style="color:#4f46e5; font-weight:600;">Sẵn sàng</td>
        </tr>
      `;
    });
    tbody.innerHTML = html;
  }

  const usersBody = document.getElementById('adminUsersTableBody');
  if (usersBody) {
    if (registeredUsers.length === 0 && currentUser.id === 'guest_user') {
      usersBody.innerHTML = `<tr><td colspan="5" style="padding:16px; color:#6b7280;">Chưa có người dùng nào đăng ký trong hệ thống.</td></tr>`;
    } else {
      const list = registeredUsers.length > 0 ? registeredUsers : [currentUser];
      usersBody.innerHTML = list.map(u => `
        <tr>
          <td style="text-align:left; padding-left:14px; font-weight:600;">${u.email}</td>
          <td><span class="role-badge ${u.role ? u.role.toLowerCase() : 'user'}">${u.role || 'USER'}</span></td>
          <td>${u.createdAt || new Date().toLocaleDateString('vi-VN')}</td>
          <td style="color:#059669; font-weight:600;">Đang hoạt động</td>
          <td>-</td>
        </tr>
      `).join('');
    }
  }
}

// 12. ABOUT PAGE ADMIN EDIT (MỤC XI)
window.toggleEditAbout = function() {
  const display = document.getElementById('aboutContentDisplay');
  const editArea = document.getElementById('aboutEditArea');
  const textarea = document.getElementById('aboutTextarea');

  if (editArea.style.display === 'none') {
    textarea.value = display.innerText;
    display.style.display = 'none';
    editArea.style.display = 'block';
  } else {
    display.style.display = 'block';
    editArea.style.display = 'none';
  }
};

window.saveAboutContent = function() {
  const val = document.getElementById('aboutTextarea').value;
  document.getElementById('aboutContentDisplay').innerText = val;
  window.toggleEditAbout();
  alert('✓ Đã cập nhật nội dung Giới thiệu!');
};

// 13. AUTH GATE & MODAL LOGIC (BẮT BUỘC ĐĂNG NHẬP & SUPABASE)
let currentGateTab = 'signin';

window.switchGateAuthTab = function(tab) {
  currentGateTab = tab;
  document.getElementById('gateTabSignIn').classList.toggle('active', tab === 'signin');
  document.getElementById('gateTabSignUp').classList.toggle('active', tab === 'signup');
  
  const nameRow = document.getElementById('gateNameRow');
  const submitBtn = document.getElementById('gateSubmitBtn');
  const errBox = document.getElementById('gateAuthError');
  if (errBox) errBox.style.display = 'none';

  if (tab === 'signup') {
    if (nameRow) nameRow.style.display = 'block';
    if (submitBtn) submitBtn.innerText = '✨ Đăng ký & Vào hệ thống';
  } else {
    if (nameRow) nameRow.style.display = 'none';
    if (submitBtn) submitBtn.innerText = '🚀 Đăng nhập vào Hệ thống';
  }
};

window.handleGateAuthSubmit = async function(e) {
  e.preventDefault();
  const email = document.getElementById('gateEmailInput').value.trim();
  const password = document.getElementById('gatePasswordInput').value;
  const nameInput = document.getElementById('gateNameInput');
  const name = (nameInput && nameInput.value.trim()) || email.split('@')[0];
  const submitBtn = document.getElementById('gateSubmitBtn');
  const errBox = document.getElementById('gateAuthError');

  if (!email || !password) return;

  if (errBox) errBox.style.display = 'none';

  if (password.length < 6) {
    if (errBox) {
      errBox.style.display = 'block';
      errBox.innerText = '⚠️ Mật khẩu trên Supabase yêu cầu tối thiểu 6 ký tự.';
    }
    return;
  }

  if (submitBtn) {
    submitBtn.disabled = true;
    submitBtn.innerText = '⏳ Đang kết nối Supabase...';
  }

  const role = (email.toLowerCase().includes('admin') || email.toLowerCase() === 'huylechill@gmail.com') ? 'ADMIN' : 'USER';
  let userId = 'u_' + Date.now();
  let supabaseSuccess = false;

  try {
    if (supabaseClient && supabaseClient.auth) {
      if (currentGateTab === 'signup') {
        const { data, error } = await supabaseClient.auth.signUp({
          email: email,
          password: password,
          options: {
            data: {
              full_name: name,
              role: role
            }
          }
        });

        if (error) {
          console.warn('Supabase Signup Error:', error);
          if (error.message.includes('already registered')) {
            if (errBox) {
              errBox.style.display = 'block';
              errBox.innerText = '⚠️ Email này đã được đăng ký trên Supabase. Vui lòng chuyển sang tab Đăng nhập!';
            }
            if (submitBtn) {
              submitBtn.disabled = false;
              submitBtn.innerText = '✨ Đăng ký & Vào hệ thống';
            }
            return;
          } else {
            // Hiển thị lỗi Supabase cho người dùng
            if (errBox) {
              errBox.style.display = 'block';
              errBox.innerText = `⚠️ Lỗi Supabase: ${error.message}`;
            }
            if (submitBtn) {
              submitBtn.disabled = false;
              submitBtn.innerText = '✨ Đăng ký & Vào hệ thống';
            }
            return;
          }
        } else {
          supabaseSuccess = true;
          if (data && data.user) {
            userId = data.user.id;
            console.log('✓ Đã tạo tài khoản thành công trên Supabase Auth:', data.user.id);
            
            // Lưu thêm vào bảng profiles hoặc users trên Supabase nếu có
            try {
              await supabaseClient.from('profiles').upsert({
                id: data.user.id,
                email: email,
                full_name: name,
                role: role,
                created_at: new Date().toISOString()
              });
            } catch (tblErr) {}
          }
        }
      } else {
        // ĐĂNG NHẬP (SIGN IN)
        const { data, error } = await supabaseClient.auth.signInWithPassword({
          email: email,
          password: password
        });

        if (error) {
          console.warn('Supabase SignIn Error:', error);
          // Nếu đăng nhập thất bại do sai mật khẩu hoặc chưa có trên Supabase
          if (errBox) {
            errBox.style.display = 'block';
            errBox.innerText = `⚠️ ${error.message === 'Invalid login credentials' ? 'Sai email hoặc mật khẩu trên Supabase. Nếu chưa có tài khoản, hãy chọn tab Đăng ký!' : error.message}`;
          }
          if (submitBtn) {
            submitBtn.disabled = false;
            submitBtn.innerText = '🚀 Đăng nhập vào Hệ thống';
          }
          return;
        } else {
          supabaseSuccess = true;
          if (data && data.user) {
            userId = data.user.id;
            console.log('✓ Đã đăng nhập Supabase thành công:', data.user.id);
          }
        }
      }
    }
  } catch (supabaseErr) {
    console.warn('Supabase network error:', supabaseErr);
  }

  // Cập nhật User Session
  currentUser = {
    id: userId,
    email: email,
    name: name,
    role: role,
    createdAt: new Date().toLocaleDateString('vi-VN')
  };
  localStorage.setItem('iris_active_user', JSON.stringify(currentUser));

  // Lưu danh sách người dùng
  const registeredUsers = JSON.parse(localStorage.getItem('iris_registered_users') || '[]');
  if (!registeredUsers.some(u => u.email === currentUser.email)) {
    registeredUsers.push(currentUser);
    localStorage.setItem('iris_registered_users', JSON.stringify(registeredUsers));
  }

  if (submitBtn) {
    submitBtn.disabled = false;
    submitBtn.innerText = '🚀 Đăng nhập thành công!';
  }

  // Mở khóa giao diện
  updateUserUI();
  loadUserData();
  
  const gate = document.getElementById('authGateScreen');
  if (gate) gate.classList.add('hidden');

  // Bắt buộc: Thứ đầu tiên hiện ra khi đăng nhập tài khoản là "Giới thiệu và Hướng dẫn"
  setTimeout(() => {
    window.openGuideModal();
  }, 250);
};

window.quickLoginGate = function(email, role) {
  currentUser = {
    id: role === 'ADMIN' ? 'admin_01' : 'user_01',
    email: email,
    name: role === 'ADMIN' ? 'Quản trị viên (Admin)' : 'Sinh viên Nghiên cứu',
    role: role,
    createdAt: new Date().toLocaleDateString('vi-VN')
  };
  localStorage.setItem('iris_active_user', JSON.stringify(currentUser));

  const registeredUsers = JSON.parse(localStorage.getItem('iris_registered_users') || '[]');
  if (!registeredUsers.some(u => u.email === currentUser.email)) {
    registeredUsers.push(currentUser);
    localStorage.setItem('iris_registered_users', JSON.stringify(registeredUsers));
  }

  updateUserUI();
  loadUserData();

  const gate = document.getElementById('authGateScreen');
  if (gate) gate.classList.add('hidden');

  // Bắt buộc: Thứ đầu tiên hiện ra khi đăng nhập tài khoản là "Giới thiệu và Hướng dẫn"
  setTimeout(() => {
    window.openGuideModal();
  }, 250);
};

window.openAuthModal = function() {
  document.getElementById('authModal').style.display = 'flex';
  if (currentUser.id !== 'guest_user' && currentUser.email) {
    document.getElementById('authLoggedInView').style.display = 'block';
    document.getElementById('authLoggedOutView').style.display = 'none';
    document.getElementById('modalUserEmail').innerText = currentUser.email;
    document.getElementById('modalUserRole').innerHTML = `<span class="role-badge ${currentUser.role.toLowerCase()}">${currentUser.role}</span>`;
  } else {
    document.getElementById('authLoggedInView').style.display = 'none';
    document.getElementById('authLoggedOutView').style.display = 'block';
  }
};

window.closeAuthModal = function() {
  document.getElementById('authModal').style.display = 'none';
};

window.switchAuthTab = function(tab) {
  document.getElementById('tabSignIn').classList.toggle('active', tab === 'signin');
  document.getElementById('tabSignUp').classList.toggle('active', tab === 'signup');
  document.getElementById('authSubmitBtn').innerText = tab === 'signin' ? 'Đăng nhập' : 'Đăng ký tài khoản';
};

window.handleAuthSubmit = async function(e) {
  e.preventDefault();
  const email = document.getElementById('authEmail').value.trim();
  const password = document.getElementById('authPassword').value;
  const role = (email.toLowerCase().includes('admin') || email.toLowerCase() === 'huylechill@gmail.com') ? 'ADMIN' : 'USER';
  let userId = 'u_' + Date.now();

  if (password && password.length < 6) {
    alert('Mật khẩu Supabase yêu cầu tối thiểu 6 ký tự!');
    return;
  }

  try {
    if (supabaseClient && supabaseClient.auth && email && password) {
      const isSignUp = document.getElementById('tabSignUp').classList.contains('active');
      if (isSignUp) {
        const { data, error } = await supabaseClient.auth.signUp({
          email,
          password,
          options: { data: { role, full_name: email.split('@')[0] } }
        });
        if (data && data.user) userId = data.user.id;
        if (error && !error.message.includes('already registered')) {
          console.warn('Supabase Signup warning:', error.message);
        }
      } else {
        const { data, error } = await supabaseClient.auth.signInWithPassword({ email, password });
        if (data && data.user) userId = data.user.id;
        if (error) {
          console.warn('Supabase Signin notice:', error.message);
        }
      }
    }
  } catch (err) {
    console.warn(err);
  }

  currentUser = {
    id: userId,
    email: email,
    name: email.split('@')[0],
    role: role,
    createdAt: new Date().toLocaleDateString('vi-VN')
  };
  localStorage.setItem('iris_active_user', JSON.stringify(currentUser));
  
  const registeredUsers = JSON.parse(localStorage.getItem('iris_registered_users') || '[]');
  if (!registeredUsers.some(u => u.email === currentUser.email)) {
    registeredUsers.push(currentUser);
    localStorage.setItem('iris_registered_users', JSON.stringify(registeredUsers));
  }

  updateUserUI();
  loadUserData();
  closeAuthModal();
  setTimeout(() => {
    window.openGuideModal();
  }, 250);
};

window.quickLoginDemo = function(email, role) {
  currentUser = {
    id: role === 'ADMIN' ? 'admin_01' : 'user_01',
    email: email,
    name: role === 'ADMIN' ? 'Quản trị viên' : 'Sinh viên Nghiên cứu',
    role: role,
    createdAt: new Date().toLocaleDateString('vi-VN')
  };
  localStorage.setItem('iris_active_user', JSON.stringify(currentUser));
  updateUserUI();
  loadUserData();
  closeAuthModal();
  setTimeout(() => {
    window.openGuideModal();
  }, 250);
};

window.switchRole = function(newRole) {
  currentUser.role = newRole;
  localStorage.setItem('iris_active_user', JSON.stringify(currentUser));
  updateUserUI();
  closeAuthModal();
};

window.handleLogout = async function() {
  if (supabaseClient && supabaseClient.auth) {
    try { await supabaseClient.auth.signOut(); } catch (e) {}
  }
  currentUser = {
    id: 'guest_user',
    email: '',
    name: '',
    role: 'USER'
  };
  localStorage.removeItem('iris_active_user');
  updateUserUI();
  loadUserData();
  closeAuthModal();
  
  // Trở về màn hình đăng nhập
  const gate = document.getElementById('authGateScreen');
  if (gate) gate.classList.remove('hidden');
};

// 14. FLOATING GUIDE BUBBLE MODAL CONTROLLER (BÓNG THÔNG BÁO NỔI MƯỢT MÀ)
window.openGuideModal = function() {
  const modal = document.getElementById('guideBubbleModal');
  if (modal) {
    modal.classList.add('active');
  }
};

window.closeGuideModal = function() {
  const modal = document.getElementById('guideBubbleModal');
  if (modal) {
    modal.classList.remove('active');
  }
};

window.handleGuideBackdropClick = function(e) {
  if (e.target.id === 'guideBubbleModal') {
    window.closeGuideModal();
  }
};

// 15. INITIALIZATION ON DOM READY
window.addEventListener('DOMContentLoaded', () => {
  initUserSession();
  trainAndRenderBoundary();
  generateRandomSample();
});
