export interface IrisSample {
  id: number;
  sepal_length: number;
  sepal_width: number;
  petal_length: number;
  petal_width: number;
  species: 'setosa' | 'versicolor' | 'virginica';
}

export const IRIS_SPECIES_NAMES = {
  setosa: 'Iris Setosa',
  versicolor: 'Iris Versicolor',
  virginica: 'Iris Virginica',
} as const;

export const IRIS_SPECIES_COLORS = {
  setosa: {
    primary: '#166534',
    bg: '#dcfce7',
    border: '#86efac',
    light: 'rgba(22, 101, 52, 0.25)',
  },
  versicolor: {
    primary: '#1e40af',
    bg: '#dbeafe',
    border: '#93c5fd',
    light: 'rgba(30, 64, 175, 0.25)',
  },
  virginica: {
    primary: '#6b21a8',
    bg: '#f3e8ff',
    border: '#d8b4fe',
    light: 'rgba(107, 33, 168, 0.25)',
  },
} as const;

export const IRIS_FEATURES = [
  { key: 'sepal_length', label: 'Sepal Length', viLabel: 'Chiều dài đài hoa', unit: 'cm', min: 4.0, max: 8.0 },
  { key: 'sepal_width', label: 'Sepal Width', viLabel: 'Chiều rộng đài hoa', unit: 'cm', min: 2.0, max: 4.5 },
  { key: 'petal_length', label: 'Petal Length', viLabel: 'Chiều dài cánh hoa', unit: 'cm', min: 1.0, max: 7.0 },
  { key: 'petal_width', label: 'Petal Width', viLabel: 'Chiều rộng cánh hoa', unit: 'cm', min: 0.1, max: 2.6 },
] as const;

export type FeatureKey = typeof IRIS_FEATURES[number]['key'];

// The complete standard 150 Iris Dataset
export const IRIS_DATASET: IrisSample[] = [
  // 50 Setosa
  { id: 1, sepal_length: 5.1, sepal_width: 3.5, petal_length: 1.4, petal_width: 0.2, species: 'setosa' },
  { id: 2, sepal_length: 4.9, sepal_width: 3.0, petal_length: 1.4, petal_width: 0.2, species: 'setosa' },
  { id: 3, sepal_length: 4.7, sepal_width: 3.2, petal_length: 1.3, petal_width: 0.2, species: 'setosa' },
  { id: 4, sepal_length: 4.6, sepal_width: 3.1, petal_length: 1.5, petal_width: 0.2, species: 'setosa' },
  { id: 5, sepal_length: 5.0, sepal_width: 3.6, petal_length: 1.4, petal_width: 0.2, species: 'setosa' },
  { id: 6, sepal_length: 5.4, sepal_width: 3.9, petal_length: 1.7, petal_width: 0.4, species: 'setosa' },
  { id: 7, sepal_length: 4.6, sepal_width: 3.4, petal_length: 1.4, petal_width: 0.3, species: 'setosa' },
  { id: 8, sepal_length: 5.0, sepal_width: 3.4, petal_length: 1.5, petal_width: 0.2, species: 'setosa' },
  { id: 9, sepal_length: 4.4, sepal_width: 2.9, petal_length: 1.4, petal_width: 0.2, species: 'setosa' },
  { id: 10, sepal_length: 4.9, sepal_width: 3.1, petal_length: 1.5, petal_width: 0.1, species: 'setosa' },
  { id: 11, sepal_length: 5.4, sepal_width: 3.7, petal_length: 1.5, petal_width: 0.2, species: 'setosa' },
  { id: 12, sepal_length: 4.8, sepal_width: 3.4, petal_length: 1.6, petal_width: 0.2, species: 'setosa' },
  { id: 13, sepal_length: 4.8, sepal_width: 3.0, petal_length: 1.4, petal_width: 0.1, species: 'setosa' },
  { id: 14, sepal_length: 4.3, sepal_width: 3.0, petal_length: 1.1, petal_width: 0.1, species: 'setosa' },
  { id: 15, sepal_length: 5.8, sepal_width: 4.0, petal_length: 1.2, petal_width: 0.2, species: 'setosa' },
  { id: 16, sepal_length: 5.7, sepal_width: 4.4, petal_length: 1.5, petal_width: 0.4, species: 'setosa' },
  { id: 17, sepal_length: 5.4, sepal_width: 3.9, petal_length: 1.3, petal_width: 0.4, species: 'setosa' },
  { id: 18, sepal_length: 5.1, sepal_width: 3.5, petal_length: 1.4, petal_width: 0.3, species: 'setosa' },
  { id: 19, sepal_length: 5.7, sepal_width: 3.8, petal_length: 1.7, petal_width: 0.3, species: 'setosa' },
  { id: 20, sepal_length: 5.1, sepal_width: 3.8, petal_length: 1.5, petal_width: 0.3, species: 'setosa' },
  { id: 21, sepal_length: 5.4, sepal_width: 3.4, petal_length: 1.7, petal_width: 0.2, species: 'setosa' },
  { id: 22, sepal_length: 5.1, sepal_width: 3.7, petal_length: 1.5, petal_width: 0.4, species: 'setosa' },
  { id: 23, sepal_length: 4.6, sepal_width: 3.6, petal_length: 1.0, petal_width: 0.2, species: 'setosa' },
  { id: 24, sepal_length: 5.1, sepal_width: 3.3, petal_length: 1.7, petal_width: 0.5, species: 'setosa' },
  { id: 25, sepal_length: 4.8, sepal_width: 3.4, petal_length: 1.9, petal_width: 0.2, species: 'setosa' },
  { id: 26, sepal_length: 5.0, sepal_width: 3.0, petal_length: 1.6, petal_width: 0.2, species: 'setosa' },
  { id: 27, sepal_length: 5.0, sepal_width: 3.4, petal_length: 1.6, petal_width: 0.4, species: 'setosa' },
  { id: 28, sepal_length: 5.2, sepal_width: 3.5, petal_length: 1.5, petal_width: 0.2, species: 'setosa' },
  { id: 29, sepal_length: 5.2, sepal_width: 3.4, petal_length: 1.4, petal_width: 0.2, species: 'setosa' },
  { id: 30, sepal_length: 4.7, sepal_width: 3.2, petal_length: 1.6, petal_width: 0.2, species: 'setosa' },
  { id: 31, sepal_length: 4.8, sepal_width: 3.1, petal_length: 1.6, petal_width: 0.2, species: 'setosa' },
  { id: 32, sepal_length: 5.4, sepal_width: 3.4, petal_length: 1.5, petal_width: 0.4, species: 'setosa' },
  { id: 33, sepal_length: 5.2, sepal_width: 4.1, petal_length: 1.5, petal_width: 0.1, species: 'setosa' },
  { id: 34, sepal_length: 5.5, sepal_width: 4.2, petal_length: 1.4, petal_width: 0.2, species: 'setosa' },
  { id: 35, sepal_length: 4.9, sepal_width: 3.1, petal_length: 1.5, petal_width: 0.2, species: 'setosa' },
  { id: 36, sepal_length: 5.0, sepal_width: 3.2, petal_length: 1.2, petal_width: 0.2, species: 'setosa' },
  { id: 37, sepal_length: 5.5, sepal_width: 3.5, petal_length: 1.3, petal_width: 0.2, species: 'setosa' },
  { id: 38, sepal_length: 4.9, sepal_width: 3.6, petal_length: 1.4, petal_width: 0.1, species: 'setosa' },
  { id: 39, sepal_length: 4.4, sepal_width: 3.0, petal_length: 1.3, petal_width: 0.2, species: 'setosa' },
  { id: 40, sepal_length: 5.1, sepal_width: 3.4, petal_length: 1.5, petal_width: 0.2, species: 'setosa' },
  { id: 41, sepal_length: 5.0, sepal_width: 3.5, petal_length: 1.3, petal_width: 0.3, species: 'setosa' },
  { id: 42, sepal_length: 4.5, sepal_width: 2.3, petal_length: 1.3, petal_width: 0.3, species: 'setosa' },
  { id: 43, sepal_length: 4.4, sepal_width: 3.2, petal_length: 1.3, petal_width: 0.2, species: 'setosa' },
  { id: 44, sepal_length: 5.0, sepal_width: 3.5, petal_length: 1.6, petal_width: 0.6, species: 'setosa' },
  { id: 45, sepal_length: 5.1, sepal_width: 3.8, petal_length: 1.9, petal_width: 0.4, species: 'setosa' },
  { id: 46, sepal_length: 4.8, sepal_width: 3.0, petal_length: 1.4, petal_width: 0.3, species: 'setosa' },
  { id: 47, sepal_length: 5.1, sepal_width: 3.8, petal_length: 1.6, petal_width: 0.2, species: 'setosa' },
  { id: 48, sepal_length: 4.6, sepal_width: 3.2, petal_length: 1.4, petal_width: 0.2, species: 'setosa' },
  { id: 49, sepal_length: 5.3, sepal_width: 3.7, petal_length: 1.5, petal_width: 0.2, species: 'setosa' },
  { id: 50, sepal_length: 5.0, sepal_width: 3.3, petal_length: 1.4, petal_width: 0.2, species: 'setosa' },

  // 50 Versicolor
  { id: 51, sepal_length: 7.0, sepal_width: 3.2, petal_length: 4.7, petal_width: 1.4, species: 'versicolor' },
  { id: 52, sepal_length: 6.4, sepal_width: 3.2, petal_length: 4.5, petal_width: 1.5, species: 'versicolor' },
  { id: 53, sepal_length: 6.9, sepal_width: 3.1, petal_length: 4.9, petal_width: 1.5, species: 'versicolor' },
  { id: 54, sepal_length: 5.5, sepal_width: 2.3, petal_length: 4.0, petal_width: 1.3, species: 'versicolor' },
  { id: 55, sepal_length: 6.5, sepal_width: 2.8, petal_length: 4.6, petal_width: 1.5, species: 'versicolor' },
  { id: 56, sepal_length: 5.7, sepal_width: 2.8, petal_length: 4.5, petal_width: 1.3, species: 'versicolor' },
  { id: 57, sepal_length: 6.3, sepal_width: 3.3, petal_length: 4.7, petal_width: 1.6, species: 'versicolor' },
  { id: 58, sepal_length: 4.9, sepal_width: 2.4, petal_length: 3.3, petal_width: 1.0, species: 'versicolor' },
  { id: 59, sepal_length: 6.6, sepal_width: 2.9, petal_length: 4.6, petal_width: 1.3, species: 'versicolor' },
  { id: 60, sepal_length: 5.2, sepal_width: 2.7, petal_length: 3.9, petal_width: 1.4, species: 'versicolor' },
  { id: 61, sepal_length: 5.0, sepal_width: 2.0, petal_length: 3.5, petal_width: 1.0, species: 'versicolor' },
  { id: 62, sepal_length: 5.9, sepal_width: 3.0, petal_length: 4.2, petal_width: 1.5, species: 'versicolor' },
  { id: 63, sepal_length: 6.0, sepal_width: 2.2, petal_length: 4.0, petal_width: 1.0, species: 'versicolor' },
  { id: 64, sepal_length: 6.1, sepal_width: 2.9, petal_length: 4.7, petal_width: 1.4, species: 'versicolor' },
  { id: 65, sepal_length: 5.6, sepal_width: 2.9, petal_length: 3.6, petal_width: 1.3, species: 'versicolor' },
  { id: 66, sepal_length: 6.7, sepal_width: 3.1, petal_length: 4.4, petal_width: 1.4, species: 'versicolor' },
  { id: 67, sepal_length: 5.6, sepal_width: 3.0, petal_length: 4.5, petal_width: 1.5, species: 'versicolor' },
  { id: 68, sepal_length: 5.8, sepal_width: 2.7, petal_length: 4.1, petal_width: 1.0, species: 'versicolor' },
  { id: 69, sepal_length: 6.2, sepal_width: 2.2, petal_length: 4.5, petal_width: 1.5, species: 'versicolor' },
  { id: 70, sepal_length: 5.6, sepal_width: 2.5, petal_length: 3.9, petal_width: 1.1, species: 'versicolor' },
  { id: 71, sepal_length: 5.9, sepal_width: 3.2, petal_length: 4.8, petal_width: 1.8, species: 'versicolor' },
  { id: 72, sepal_length: 6.1, sepal_width: 2.8, petal_length: 4.0, petal_width: 1.3, species: 'versicolor' },
  { id: 73, sepal_length: 6.3, sepal_width: 2.5, petal_length: 4.9, petal_width: 1.5, species: 'versicolor' },
  { id: 74, sepal_length: 6.1, sepal_width: 2.8, petal_length: 4.7, petal_width: 1.2, species: 'versicolor' },
  { id: 75, sepal_length: 6.4, sepal_width: 2.9, petal_length: 4.3, petal_width: 1.3, species: 'versicolor' },
  { id: 76, sepal_length: 6.6, sepal_width: 3.0, petal_length: 4.4, petal_width: 1.4, species: 'versicolor' },
  { id: 77, sepal_length: 6.8, sepal_width: 2.8, petal_length: 4.8, petal_width: 1.4, species: 'versicolor' },
  { id: 78, sepal_length: 6.7, sepal_width: 3.0, petal_length: 5.0, petal_width: 1.7, species: 'versicolor' },
  { id: 79, sepal_length: 6.0, sepal_width: 2.9, petal_length: 4.5, petal_width: 1.5, species: 'versicolor' },
  { id: 80, sepal_length: 5.7, sepal_width: 2.6, petal_length: 3.5, petal_width: 1.0, species: 'versicolor' },
  { id: 81, sepal_length: 5.5, sepal_width: 2.4, petal_length: 3.8, petal_width: 1.1, species: 'versicolor' },
  { id: 82, sepal_length: 5.5, sepal_width: 2.4, petal_length: 3.7, petal_width: 1.0, species: 'versicolor' },
  { id: 83, sepal_length: 5.8, sepal_width: 2.7, petal_length: 3.9, petal_width: 1.2, species: 'versicolor' },
  { id: 84, sepal_length: 6.0, sepal_width: 2.7, petal_length: 5.1, petal_width: 1.6, species: 'versicolor' },
  { id: 85, sepal_length: 5.4, sepal_width: 3.0, petal_length: 4.5, petal_width: 1.5, species: 'versicolor' },
  { id: 86, sepal_length: 6.0, sepal_width: 3.4, petal_length: 4.5, petal_width: 1.6, species: 'versicolor' },
  { id: 87, sepal_length: 6.7, sepal_width: 3.1, petal_length: 4.7, petal_width: 1.5, species: 'versicolor' },
  { id: 88, sepal_length: 6.3, sepal_width: 2.3, petal_length: 4.4, petal_width: 1.3, species: 'versicolor' },
  { id: 89, sepal_length: 5.6, sepal_width: 3.0, petal_length: 4.1, petal_width: 1.3, species: 'versicolor' },
  { id: 90, sepal_length: 5.5, sepal_width: 2.5, petal_length: 4.0, petal_width: 1.3, species: 'versicolor' },
  { id: 91, sepal_length: 5.5, sepal_width: 2.6, petal_length: 4.4, petal_width: 1.2, species: 'versicolor' },
  { id: 92, sepal_length: 6.1, sepal_width: 3.0, petal_length: 4.6, petal_width: 1.4, species: 'versicolor' },
  { id: 93, sepal_length: 5.8, sepal_width: 2.6, petal_length: 4.0, petal_width: 1.2, species: 'versicolor' },
  { id: 94, sepal_length: 5.0, sepal_width: 2.3, petal_length: 3.3, petal_width: 1.0, species: 'versicolor' },
  { id: 95, sepal_length: 5.6, sepal_width: 2.7, petal_length: 4.2, petal_width: 1.3, species: 'versicolor' },
  { id: 96, sepal_length: 5.7, sepal_width: 3.0, petal_length: 4.2, petal_width: 1.2, species: 'versicolor' },
  { id: 97, sepal_length: 5.7, sepal_width: 2.9, petal_length: 4.2, petal_width: 1.3, species: 'versicolor' },
  { id: 98, sepal_length: 6.2, sepal_width: 2.9, petal_length: 4.3, petal_width: 1.3, species: 'versicolor' },
  { id: 99, sepal_length: 5.1, sepal_width: 2.5, petal_length: 3.0, petal_width: 1.1, species: 'versicolor' },
  { id: 100, sepal_length: 5.7, sepal_width: 2.8, petal_length: 4.1, petal_width: 1.3, species: 'versicolor' },

  // 50 Virginica
  { id: 101, sepal_length: 6.3, sepal_width: 3.3, petal_length: 6.0, petal_width: 2.5, species: 'virginica' },
  { id: 102, sepal_length: 5.8, sepal_width: 2.7, petal_length: 5.1, petal_width: 1.9, species: 'virginica' },
  { id: 103, sepal_length: 7.1, sepal_width: 3.0, petal_length: 5.9, petal_width: 2.1, species: 'virginica' },
  { id: 104, sepal_length: 6.3, sepal_width: 2.9, petal_length: 5.6, petal_width: 1.8, species: 'virginica' },
  { id: 105, sepal_length: 6.5, sepal_width: 3.0, petal_length: 5.8, petal_width: 2.2, species: 'virginica' },
  { id: 106, sepal_length: 7.6, sepal_width: 3.0, petal_length: 6.6, petal_width: 2.1, species: 'virginica' },
  { id: 107, sepal_length: 4.9, sepal_width: 2.5, petal_length: 4.5, petal_width: 1.7, species: 'virginica' },
  { id: 108, sepal_length: 7.3, sepal_width: 2.9, petal_length: 6.3, petal_width: 1.8, species: 'virginica' },
  { id: 109, sepal_length: 6.7, sepal_width: 2.5, petal_length: 5.8, petal_width: 1.8, species: 'virginica' },
  { id: 110, sepal_length: 7.2, sepal_width: 3.6, petal_length: 6.1, petal_width: 2.5, species: 'virginica' },
  { id: 111, sepal_length: 6.5, sepal_width: 3.2, petal_length: 5.1, petal_width: 2.0, species: 'virginica' },
  { id: 112, sepal_length: 6.4, sepal_width: 2.7, petal_length: 5.3, petal_width: 1.9, species: 'virginica' },
  { id: 113, sepal_length: 6.8, sepal_width: 3.0, petal_length: 5.5, petal_width: 2.1, species: 'virginica' },
  { id: 114, sepal_length: 5.7, sepal_width: 2.5, petal_length: 5.0, petal_width: 2.0, species: 'virginica' },
  { id: 115, sepal_length: 5.8, sepal_width: 2.8, petal_length: 5.1, petal_width: 2.4, species: 'virginica' },
  { id: 116, sepal_length: 6.4, sepal_width: 3.2, petal_length: 5.3, petal_width: 2.3, species: 'virginica' },
  { id: 117, sepal_length: 6.5, sepal_width: 3.0, petal_length: 5.5, petal_width: 1.8, species: 'virginica' },
  { id: 118, sepal_length: 7.7, sepal_width: 3.8, petal_length: 6.7, petal_width: 2.2, species: 'virginica' },
  { id: 119, sepal_length: 7.7, sepal_width: 2.6, petal_length: 6.9, petal_width: 2.3, species: 'virginica' },
  { id: 120, sepal_length: 6.0, sepal_width: 2.2, petal_length: 5.0, petal_width: 1.5, species: 'virginica' },
  { id: 121, sepal_length: 6.9, sepal_width: 3.2, petal_length: 5.7, petal_width: 2.3, species: 'virginica' },
  { id: 122, sepal_length: 5.6, sepal_width: 2.8, petal_length: 4.9, petal_width: 2.0, species: 'virginica' },
  { id: 123, sepal_length: 7.7, sepal_width: 2.8, petal_length: 6.7, petal_width: 2.0, species: 'virginica' },
  { id: 124, sepal_length: 6.3, sepal_width: 2.7, petal_length: 4.9, petal_width: 1.8, species: 'virginica' },
  { id: 125, sepal_length: 6.7, sepal_width: 3.3, petal_length: 5.7, petal_width: 2.1, species: 'virginica' },
  { id: 126, sepal_length: 7.2, sepal_width: 3.2, petal_length: 6.0, petal_width: 1.8, species: 'virginica' },
  { id: 127, sepal_length: 6.2, sepal_width: 2.8, petal_length: 4.8, petal_width: 1.8, species: 'virginica' },
  { id: 128, sepal_length: 6.1, sepal_width: 3.0, petal_length: 4.9, petal_width: 1.8, species: 'virginica' },
  { id: 129, sepal_length: 6.4, sepal_width: 2.8, petal_length: 5.6, petal_width: 2.1, species: 'virginica' },
  { id: 130, sepal_length: 7.2, sepal_width: 3.0, petal_length: 5.8, petal_width: 1.6, species: 'virginica' },
  { id: 131, sepal_length: 7.4, sepal_width: 2.8, petal_length: 6.1, petal_width: 1.9, species: 'virginica' },
  { id: 132, sepal_length: 7.9, sepal_width: 3.8, petal_length: 6.4, petal_width: 2.0, species: 'virginica' },
  { id: 133, sepal_length: 6.4, sepal_width: 2.8, petal_length: 5.6, petal_width: 2.2, species: 'virginica' },
  { id: 134, sepal_length: 6.3, sepal_width: 2.8, petal_length: 5.1, petal_width: 1.5, species: 'virginica' },
  { id: 135, sepal_length: 6.1, sepal_width: 2.6, petal_length: 5.6, petal_width: 1.4, species: 'virginica' },
  { id: 136, sepal_length: 7.7, sepal_width: 3.0, petal_length: 6.1, petal_width: 2.3, species: 'virginica' },
  { id: 137, sepal_length: 6.3, sepal_width: 3.4, petal_length: 5.6, petal_width: 2.4, species: 'virginica' },
  { id: 138, sepal_length: 6.4, sepal_width: 3.1, petal_length: 5.5, petal_width: 1.8, species: 'virginica' },
  { id: 139, sepal_length: 6.0, sepal_width: 3.0, petal_length: 4.8, petal_width: 1.8, species: 'virginica' },
  { id: 140, sepal_length: 6.9, sepal_width: 3.1, petal_length: 5.4, petal_width: 2.1, species: 'virginica' },
  { id: 141, sepal_length: 6.7, sepal_width: 3.1, petal_length: 5.6, petal_width: 2.4, species: 'virginica' },
  { id: 142, sepal_length: 6.9, sepal_width: 3.1, petal_length: 5.1, petal_width: 2.3, species: 'virginica' },
  { id: 143, sepal_length: 5.8, sepal_width: 2.7, petal_length: 5.1, petal_width: 1.9, species: 'virginica' },
  { id: 144, sepal_length: 6.8, sepal_width: 3.2, petal_length: 5.9, petal_width: 2.3, species: 'virginica' },
  { id: 145, sepal_length: 6.7, sepal_width: 3.3, petal_length: 5.7, petal_width: 2.5, species: 'virginica' },
  { id: 146, sepal_length: 6.7, sepal_width: 3.0, petal_length: 5.2, petal_width: 2.3, species: 'virginica' },
  { id: 147, sepal_length: 6.3, sepal_width: 2.5, petal_length: 5.0, petal_width: 1.9, species: 'virginica' },
  { id: 148, sepal_length: 6.5, sepal_width: 3.0, petal_length: 5.2, petal_width: 2.0, species: 'virginica' },
  { id: 149, sepal_length: 6.2, sepal_width: 3.4, petal_length: 5.4, petal_width: 2.3, species: 'virginica' },
  { id: 150, sepal_length: 5.9, sepal_width: 3.0, petal_length: 5.1, petal_width: 1.8, species: 'virginica' },
];

export function getFeatureStats(feature: FeatureKey, speciesFilter?: 'setosa' | 'versicolor' | 'virginica') {
  const filtered = speciesFilter 
    ? IRIS_DATASET.filter(d => d.species === speciesFilter)
    : IRIS_DATASET;
  const values = filtered.map(d => d[feature]);
  const min = Math.min(...values);
  const max = Math.max(...values);
  const sum = values.reduce((a, b) => a + b, 0);
  const mean = sum / values.length;
  const variance = values.reduce((acc, v) => acc + Math.pow(v - mean, 2), 0) / values.length;
  const std = Math.sqrt(variance);

  return {
    min: Number(min.toFixed(2)),
    max: Number(max.toFixed(2)),
    mean: Number(mean.toFixed(2)),
    std: Number(std.toFixed(2)),
    count: values.length,
  };
}
